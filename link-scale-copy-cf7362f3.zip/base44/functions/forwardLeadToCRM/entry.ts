import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const CRM_WEBHOOK_URL = "https://prime-crm-nexus.base44.app/functions/webhookCreateLead";

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const body = await req.json();
    const { event, data, payload_too_large } = body;

    if (event?.type !== 'create') {
      return Response.json({ skipped: true, reason: 'not a create event' });
    }

    let lead = data;
    if (payload_too_large && event?.entity_id) {
      lead = await base44.asServiceRole.entities.Lead.get(event.entity_id);
    }
    if (!lead) {
      return Response.json({ skipped: true, reason: 'no lead data' });
    }

    // Classification label
    const classificationLabel =
      lead.classification === 'diy' ? 'DIY - מדריך'
      : lead.classification === 'managed' ? 'Managed - שיחת ייעוץ'
      : '';

    // Build answers text (Q&A formatted)
    const answers = Array.isArray(lead.answers) ? lead.answers : [];
    const answersText = answers
      .map((a, i) => `${i + 1}. ${a?.question || ''}\n   תשובה: ${a?.answer || ''}`)
      .join('\n\n');

    // --- 1) Forward to CRM (existing flow) ---
    const crmPayload = {
      name: lead.name || '',
      email: lead.email || '',
      phone: lead.phone || '',
      source: 'LinkBoost Landing',
      product_service: classificationLabel,
      occupation: classificationLabel,
    };

    const crmRes = await fetch(CRM_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(crmPayload),
    });
    const crmText = await crmRes.text();
    console.log('CRM response status:', crmRes.status, 'body:', crmText);

    // --- 2) Forward to Make.com (configurable) ---
    let makeResult = { skipped: true, reason: 'no webhook configured' };
    try {
      const configs = await base44.asServiceRole.entities.AppConfiguration.filter({ key: 'make_webhook_url' });
      const makeUrl = configs?.[0]?.value?.trim();

      if (makeUrl) {
        const makePayload = {
          lead_id: lead.id,
          created_date: lead.created_date,
          name: lead.name || '',
          email: lead.email || '',
          phone: lead.phone || '',
          classification: lead.classification || '',
          classification_label: classificationLabel,
          status: lead.status || 'new',
          source: 'LinkBoost Landing',
          answers,
          answers_text: answersText,
          summary: `ליד חדש: ${lead.name || ''}\nאימייל: ${lead.email || ''}\nטלפון: ${lead.phone || ''}\nסיווג: ${classificationLabel}\n\nתשובות השאלון:\n${answersText}`,
        };

        const makeRes = await fetch(makeUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(makePayload),
        });
        const makeText = await makeRes.text();
        console.log('Make.com response status:', makeRes.status, 'body:', makeText);
        makeResult = { ok: makeRes.ok, status: makeRes.status, body: makeText };
      }
    } catch (e) {
      console.error('Make.com forward error:', e);
      makeResult = { error: e.message };
    }

    if (!crmRes.ok) {
      return Response.json({ error: 'CRM webhook failed', status: crmRes.status, body: crmText, make: makeResult }, { status: 500 });
    }

    return Response.json({ success: true, lead_id: lead.id, make: makeResult });
  } catch (error) {
    console.error('forwardLeadToCRM error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});