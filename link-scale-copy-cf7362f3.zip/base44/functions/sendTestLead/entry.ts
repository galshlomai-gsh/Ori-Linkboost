import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Forbidden: Admin access required' }, { status: 403 });
    }

    // Load active questions from the live quiz (ordered)
    const questions = await base44.asServiceRole.entities.Question.filter(
      { is_active: true },
      'order_index',
      100
    );

    const answers = [];
    let classification = '';

    for (const q of questions) {
      if (q.type === 'text') {
        answers.push({ question: q.title, answer: 'תשובה לדוגמה (טסט אוטומטי)' });
      } else if (Array.isArray(q.options) && q.options.length > 0) {
        const chosen = pickRandom(q.options);
        answers.push({ question: q.title, answer: chosen?.label || chosen?.value || '' });
        if (chosen?.classification && !classification) {
          classification = chosen.classification;
        }
      }
    }

    if (!classification) classification = Math.random() < 0.5 ? 'diy' : 'managed';

    const rnd = Math.floor(Math.random() * 9000) + 1000;
    const testLead = {
      name: `ליד בדיקה ${rnd}`,
      email: `test${rnd}@example.com`,
      phone: `050-${String(rnd).padStart(4, '0')}123`,
      classification,
      status: 'new',
      answers,
    };

    const created = await base44.asServiceRole.entities.Lead.create(testLead);
    return Response.json({
      success: true,
      lead_id: created.id,
      questions_count: answers.length,
      classification,
      message: `נוצר ליד טסט עם ${answers.length} תשובות רנדומליות. ה-Webhook יופעל אוטומטית.`,
    });
  } catch (error) {
    console.error('sendTestLead error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});