import { useEffect, useRef } from "react";
import { useToast } from "@/components/ui/use-toast";
import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
} from "@/components/ui/toast";

const DEFAULT_DURATION = 2000;

function AutoDismissToast({ id, title, description, action, duration, dismiss, ...props }) {
  const timerRef = useRef(null);

  useEffect(() => {
    const ms = duration ?? DEFAULT_DURATION;
    timerRef.current = setTimeout(() => dismiss(id), ms);
    return () => clearTimeout(timerRef.current);
  }, [id, duration, dismiss]);

  return (
    <Toast {...props}>
      <div className="grid gap-1">
        {title && <ToastTitle>{title}</ToastTitle>}
        {description && <ToastDescription>{description}</ToastDescription>}
      </div>
      {action}
      <ToastClose />
    </Toast>
  );
}

export function Toaster() {
  const { toasts, dismiss } = useToast();

  return (
    <ToastProvider>
      {toasts.map(({ id, title, description, action, duration, ...props }) => (
        <AutoDismissToast
          key={id}
          id={id}
          title={title}
          description={description}
          action={action}
          duration={duration}
          dismiss={dismiss}
          {...props}
        />
      ))}
      <ToastViewport />
    </ToastProvider>
  );
}