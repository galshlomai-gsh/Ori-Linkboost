import React, { useState, useRef, useEffect } from "react";
import { createPortal } from "react-dom";
import { Palette, Check, EyeOff } from "lucide-react";
import { FIELD_STYLES, DEFAULT_FIELD_STYLE } from "./fieldStyles";

/**
 * Small floating picker shown next to an editable field in inline-edit mode.
 * Rendered via a portal so it escapes any `overflow-hidden` ancestor.
 */
export default function StylePicker({ field, currentKey, onSelect }) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState({ top: 0, left: 0 });
  const btnRef = useRef(null);
  const menuRef = useRef(null);

  const updatePos = () => {
    const r = btnRef.current?.getBoundingClientRect();
    if (!r) return;
    const menuWidth = 220;
    // Align menu's right edge to button's right edge (RTL)
    let left = r.right - menuWidth;
    if (left < 8) left = 8;
    if (left + menuWidth > window.innerWidth - 8) left = window.innerWidth - menuWidth - 8;
    setPos({ top: r.bottom + 6, left });
  };

  useEffect(() => {
    if (!open) return;
    updatePos();
    const handler = (e) => {
      if (
        menuRef.current && !menuRef.current.contains(e.target) &&
        btnRef.current && !btnRef.current.contains(e.target)
      ) setOpen(false);
    };
    const onScroll = () => updatePos();
    document.addEventListener("mousedown", handler);
    window.addEventListener("scroll", onScroll, true);
    window.addEventListener("resize", onScroll);
    return () => {
      document.removeEventListener("mousedown", handler);
      window.removeEventListener("scroll", onScroll, true);
      window.removeEventListener("resize", onScroll);
    };
  }, [open]);

  const activeKey = currentKey || DEFAULT_FIELD_STYLE[field] || "body";

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setOpen((v) => !v);
        }}
        className="inline-flex items-center justify-center w-5 h-5 rounded bg-accent/70 text-accent-foreground hover:bg-accent border border-border/50 align-middle mr-1"
        title="בחר עיצוב"
      >
        <Palette className="w-3 h-3" />
      </button>

      {open && createPortal(
        <div
          ref={menuRef}
          dir="rtl"
          style={{ position: "fixed", top: pos.top, left: pos.left, width: 220 }}
          className="z-[9999] bg-popover border border-border rounded-lg shadow-xl p-1 max-h-[70vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="px-2 py-1.5 text-[10px] text-muted-foreground uppercase tracking-wide">בחר עיצוב לשדה</div>
          <button
            type="button"
            onClick={async (e) => {
              e.preventDefault();
              e.stopPropagation();
              await onSelect("hidden");
              setOpen(false);
            }}
            className={`flex items-center justify-between w-full text-right px-2 py-1.5 rounded text-xs hover:bg-destructive/10 text-destructive ${
              activeKey === "hidden" ? "bg-destructive/10" : ""
            }`}
          >
            <span className="flex items-center gap-1.5"><EyeOff className="w-3 h-3" /> אל תציג שדה זה</span>
            {activeKey === "hidden" && <Check className="w-3 h-3" />}
          </button>
          <div className="h-px bg-border my-1" />
          {Object.entries(FIELD_STYLES).map(([key, cfg]) => (
            <button
              key={key}
              type="button"
              onClick={async (e) => {
                e.preventDefault();
                e.stopPropagation();
                await onSelect(key);
                setOpen(false);
              }}
              className={`flex items-center justify-between w-full text-right px-2 py-1.5 rounded text-xs hover:bg-secondary ${
                key === activeKey ? "bg-secondary/60" : ""
              }`}
            >
              <span>{cfg.label}</span>
              {key === activeKey && <Check className="w-3 h-3 text-primary" />}
            </button>
          ))}
        </div>,
        document.body
      )}
    </>
  );
}