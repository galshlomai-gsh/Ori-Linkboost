import React, { useState, useRef, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useInlineEdit } from "./InlineEditContext";
import { Pencil, Check, X, Bold } from "lucide-react";
import StylePicker from "./StylePicker";
import { FIELD_STYLES } from "./fieldStyles";

/**
 * EditableText — renders content from LandingContent and, when inline-edit mode is on,
 * lets admin click to edit in place. Falls back to plain text in normal mode.
 *
 * Props:
 *  - section: section key (e.g. "hero")
 *  - k: content key within section (e.g. "headline_line1")
 *  - fallback: default text if no content exists
 *  - as: element tag to render as (default: "span")
 *  - multiline: allow multi-line editing
 *  - className: applied to the rendered element
 */
export default function EditableText({
  section,
  k,
  fallback = "",
  as: Tag = "span",
  multiline = false,
  className = "",
  children,
  styleable = false,
}) {
  const { enabled } = useInlineEdit();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState("");
  const [saving, setSaving] = useState(false);
  const inputRef = useRef(null);

  const { data: items = [] } = useQuery({
    queryKey: ["landing_content", section],
    queryFn: () => base44.entities.LandingContent.filter({ section }, "order_index", 100),
    staleTime: 30000,
  });

  const item = items.find((d) => d.key === k);
  const value = item ? item.value : fallback;

  // Optional style support: store selected style key in a sibling LandingContent row.
  const styleKey = `${k}__style`;
  const styleItem = styleable ? items.find((d) => d.key === styleKey) : null;
  const selectedStyleKey = styleItem?.value || null;
  const isHidden = styleable && selectedStyleKey === "hidden";
  const styleClassName = styleable && selectedStyleKey && FIELD_STYLES[selectedStyleKey]
    ? FIELD_STYLES[selectedStyleKey].className
    : "";
  const mergedClassName = `${className} ${styleClassName}`.trim();

  const updateStyle = async (newKey) => {
    if (styleItem) {
      await base44.entities.LandingContent.update(styleItem.id, { value: newKey });
    } else {
      const maxOrder = items.reduce((m, it) => Math.max(m, it.order_index ?? 0), -1);
      await base44.entities.LandingContent.create({
        section,
        key: styleKey,
        value: newKey,
        order_index: maxOrder + 1,
      });
    }
    await queryClient.invalidateQueries({ queryKey: ["landing_content", section] });
    await queryClient.invalidateQueries({ queryKey: ["landing_content"] });
  };

  useEffect(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select?.();
    }
  }, [editing]);

  const startEdit = (e) => {
    if (!enabled) return;
    e.preventDefault();
    e.stopPropagation();
    setVal(value);
    setEditing(true);
  };

  const cancel = () => {
    setEditing(false);
    setVal("");
  };

  const save = async () => {
    if (val === value) {
      setEditing(false);
      return;
    }
    setSaving(true);
    try {
      if (item) {
        await base44.entities.LandingContent.update(item.id, { value: val });
      } else {
        const maxOrder = items.reduce((m, it) => Math.max(m, it.order_index ?? 0), -1);
        await base44.entities.LandingContent.create({
          section,
          key: k,
          value: val,
          order_index: maxOrder + 1,
        });
      }
      await queryClient.invalidateQueries({ queryKey: ["landing_content", section] });
      await queryClient.invalidateQueries({ queryKey: ["landing_content"] });
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  const wrapBold = () => {
    const el = inputRef.current;
    if (!el) return;
    const start = el.selectionStart ?? val.length;
    const end = el.selectionEnd ?? val.length;
    const selected = val.substring(start, end) || "טקסט מודגש";
    const newVal = val.substring(0, start) + `**${selected}**` + val.substring(end);
    setVal(newVal);
    setTimeout(() => {
      el.focus();
      el.setSelectionRange(start + 2, start + 2 + selected.length);
    }, 0);
  };

  const handleKeyDown = (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      cancel();
    } else if ((e.ctrlKey || e.metaKey) && (e.key === "b" || e.key === "B")) {
      e.preventDefault();
      wrapBold();
    } else if (e.key === "Enter" && (!multiline || e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      save();
    }
  };

  // Not in edit mode → render as a plain element (keeps original layout/style intact)
  if (!enabled) {
    if (isHidden) return null;
    const finalClass = multiline ? `${mergedClassName} whitespace-pre-line`.trim() : mergedClassName;
    return <Tag className={finalClass}>{children ?? value}</Tag>;
  }

  // Edit mode but not currently editing → render with hover affordance
  if (!editing) {
    if (isHidden) {
      return (
        <Tag className="inline-flex items-center gap-2 px-2 py-1 rounded border border-dashed border-muted-foreground/40 bg-muted/30 text-xs text-muted-foreground opacity-70">
          <span>שדה מוסתר: {k}</span>
          {styleable && <StylePicker field={k} currentKey={selectedStyleKey} onSelect={updateStyle} />}
        </Tag>
      );
    }
    const multilineClass = multiline ? "whitespace-pre-line" : "";
    return (
      <Tag
        className={`${mergedClassName} ${multilineClass} relative cursor-text outline outline-1 outline-transparent hover:outline-primary/60 hover:bg-primary/5 rounded transition-colors`}
        onClick={startEdit}
        title="לחץ לעריכה"
      >
        {children ?? value}
        {styleable && <StylePicker field={k} currentKey={selectedStyleKey} onSelect={updateStyle} />}
        <Pencil className="inline-block w-3 h-3 mr-1 text-primary/70 align-baseline" />
      </Tag>
    );
  }

  // Active editor — overlay input/textarea on top of original layout
  return (
    <Tag
      className={`${className} relative ${multiline ? "block w-full" : "inline-block align-baseline"}`}
      style={multiline ? undefined : { minWidth: "4ch" }}
    >
      {multiline ? (
        <textarea
          ref={inputRef}
          value={val}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={handleKeyDown}
          dir="rtl"
          rows={Math.max(6, val.split("\n").length + 1)}
          className="block w-full min-w-full md:min-w-[600px] min-h-[180px] bg-background/95 border-2 border-primary rounded-lg p-3 text-current font-[inherit] leading-relaxed resize-y outline-none focus:ring-2 focus:ring-primary/40"
        />
      ) : (
        <input
          ref={inputRef}
          value={val}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={handleKeyDown}
          dir="rtl"
          className="w-full min-w-[180px] bg-background/95 border-2 border-primary rounded-md px-2 py-0.5 text-current font-[inherit] outline-none focus:ring-2 focus:ring-primary/40"
          style={{ fontSize: "inherit", fontWeight: "inherit", lineHeight: "inherit", color: "inherit" }}
        />
      )}
      <span className="inline-flex items-center gap-1 mr-2 align-middle">
        <button
          type="button"
          onMouseDown={(e) => { e.preventDefault(); wrapBold(); }}
          className="inline-flex items-center justify-center w-6 h-6 rounded bg-secondary text-foreground hover:bg-secondary/80 border border-border"
          title="הדגשה (Ctrl/Cmd+B) — סמן טקסט ולחץ"
        >
          <Bold className="w-3.5 h-3.5" />
        </button>
        <button
          type="button"
          onClick={save}
          disabled={saving}
          className="inline-flex items-center justify-center w-6 h-6 rounded bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          title="שמור (Enter)"
        >
          <Check className="w-3.5 h-3.5" />
        </button>
        <button
          type="button"
          onClick={cancel}
          className="inline-flex items-center justify-center w-6 h-6 rounded bg-secondary text-foreground hover:bg-secondary/80 border border-border"
          title="ביטול (Esc)"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </span>
    </Tag>
  );
}