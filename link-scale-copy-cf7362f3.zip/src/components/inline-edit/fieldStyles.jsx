// Style presets for inline-editable fields in CustomSectionRenderer.
// Each preset provides: label (for picker), className (applied to the rendered element),
// and isMultiline (whether the input should be a textarea).

export const FIELD_STYLES = {
  badge: {
    label: "תווית קטנה",
    className: "text-xs text-primary font-medium",
    isMultiline: false,
  },
  heading: {
    label: "כותרת ראשית",
    className: "font-heading text-3xl md:text-5xl font-extrabold leading-[1.15] text-foreground",
    isMultiline: false,
  },
  heading_highlight: {
    label: "כותרת צבעונית",
    className: "font-heading text-3xl md:text-5xl font-extrabold leading-[1.15] bg-gradient-to-l from-primary via-cyan-400 to-primary bg-clip-text text-transparent",
    isMultiline: false,
  },
  subheading: {
    label: "תת-כותרת",
    className: "text-sm md:text-base text-muted-foreground max-w-2xl mx-auto block",
    isMultiline: true,
  },
  body: {
    label: "גוף טקסט",
    className: "text-base md:text-lg text-foreground/90 leading-relaxed whitespace-pre-line",
    isMultiline: true,
  },
  body_large: {
    label: "גוף טקסט גדול",
    className: "text-lg md:text-2xl font-semibold text-foreground leading-relaxed whitespace-pre-line",
    isMultiline: true,
  },
  body_emphasis: {
    label: "גוף טקסט מודגש",
    className: "text-base md:text-xl font-bold text-primary leading-relaxed whitespace-pre-line",
    isMultiline: true,
  },
  note: {
    label: "הערה קטנה",
    className: "text-xs text-muted-foreground",
    isMultiline: false,
  },
  customer_name: {
    label: "שם לקוח",
    className: "font-heading font-bold text-lg text-foreground",
    isMultiline: false,
  },
  customer_role: {
    label: "תפקיד / חברה",
    className: "text-sm text-muted-foreground",
    isMultiline: false,
  },
};

// Default style key for each known field
export const DEFAULT_FIELD_STYLE = {
  badge: "badge",
  heading: "heading",
  heading_highlight: "heading_highlight",
  subheading: "subheading",
  body: "body",
  customer_name: "customer_name",
  customer_role: "customer_role",
};

export function getStyleConfig(field, overrides) {
  const overrideKey = overrides?.[field];
  const key = overrideKey || DEFAULT_FIELD_STYLE[field] || "body";
  return FIELD_STYLES[key] || FIELD_STYLES.body;
}