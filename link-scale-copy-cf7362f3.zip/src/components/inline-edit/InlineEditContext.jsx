import React, { createContext, useContext } from "react";

const InlineEditContext = createContext({ enabled: false });

export function InlineEditProvider({ children, enabled = false }) {
  return (
    <InlineEditContext.Provider value={{ enabled }}>
      {children}
    </InlineEditContext.Provider>
  );
}

export function useInlineEdit() {
  return useContext(InlineEditContext);
}