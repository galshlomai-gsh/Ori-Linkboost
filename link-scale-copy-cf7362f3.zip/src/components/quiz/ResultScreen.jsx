import React, { useState } from "react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { BookOpen, Headphones, CheckCircle2, Loader2, ArrowLeft } from "lucide-react";
import EditableText from "@/components/inline-edit/EditableText";

export default function ResultScreen({ classification, gender, onSubmit }) {
  const [form, setForm] = useState({ name: "", email: "", phone: "", company: "" });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const isDIY = classification === "diy";
  const isFemale = gender === "female";

  // Gender-aware text helper: t(male, female)
  const t = (male, female) => isFemale ? female : male;

  // Load editable placeholders from LandingContent (section="result")
  const { data: resultContent = [] } = useQuery({
    queryKey: ["landing_content", "result"],
    queryFn: () => base44.entities.LandingContent.filter({ section: "result" }, "order_index", 200),
    staleTime: 30000,
  });
  const getText = (key, fallback) => {
    const item = resultContent.find((d) => d.key === key);
    return item?.value || fallback;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true);
    await onSubmit(form);
    setSubmitting(false);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        className="text-center py-12"
        dir="rtl"
      >
        <div className="w-20 h-20 rounded-full bg-primary/15 border border-primary/25 flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-10 h-10 text-primary" />
        </div>
        <EditableText
          section="result"
          k={isDIY ? "success_title_diy" : "success_title_managed"}
          fallback={isDIY ? "נשלח לך המדריך! 📬" : "מעולה, נדבר בקרוב! 🤝"}
          as="h3"
          styleable
          className="font-heading text-2xl font-bold mb-3"
        />
        <EditableText
          section="result"
          k={isDIY ? (isFemale ? "success_body_diy_f" : "success_body_diy_m") : (isFemale ? "success_body_managed_f" : "success_body_managed_m")}
          fallback={isDIY
            ? t("שלחנו לך לאימייל מדריך מפורט לבניית קישורים בעצמך. תחזור אלינו כשתרצה שנקח את זה ממך.", "שלחנו לך לאימייל מדריך מפורט לבניית קישורים בעצמך. תחזרי אלינו כשתרצי שנקח את זה ממך.")
            : t("יועץ SEO בכיר יחזור אליך תוך 24 שעות לשיחת ייעוץ קצרה. נבנה יחד מערך קישורים שעובד.", "יועץ SEO בכיר יחזור אליך תוך 24 שעות לשיחת ייעוץ קצרה. נבנה יחד מערך קישורים שעובד.")}
          as="p"
          multiline
          styleable
          className="text-muted-foreground max-w-sm mx-auto text-sm leading-relaxed"
        />
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-lg mx-auto"
      dir="rtl"
    >
      {/* Result card */}
      <div className={`p-5 rounded-2xl border mb-7 ${
        isDIY
          ? "bg-muted/40 border-border/50"
          : "bg-primary/8 border-primary/25"
      }`}>
        <div className="flex items-start gap-3">
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${
            isDIY ? "bg-muted" : "bg-primary/15"
          }`}>
            {isDIY
              ? <BookOpen className="w-5 h-5 text-muted-foreground" />
              : <Headphones className="w-5 h-5 text-primary" />
            }
          </div>
          <div>
            <EditableText
              section="result"
              k={isDIY ? (isFemale ? "card_title_diy_f" : "card_title_diy_m") : "card_title_managed"}
              fallback={isDIY
                ? t("נראה שאתה מעדיף להמשיך לנהל קישורים בעצמך", "נראה שאת מעדיפה להמשיך לנהל קישורים בעצמך")
                : "בדיוק בשביל זה אנחנו כאן 🎯"}
              as="h3"
              styleable
              className="font-heading font-bold text-lg leading-tight"
            />
            <EditableText
              section="result"
              k={isDIY ? (isFemale ? "card_body_diy_f" : "card_body_diy_m") : (isFemale ? "card_body_managed_f" : "card_body_managed_m")}
              fallback={isDIY
                ? t("אין בעיה – שלחנו לך מדריך מפורט שיעזור לך לבנות קישורים בצורה נכונה. ואם בשלב מסוים תרצה שנקח את זה ממך – אנחנו כאן.", "אין בעיה – שלחנו לך מדריך מפורט שיעזור לך לבנות קישורים בצורה נכונה. ואם בשלב מסוים תרצי שנקח את זה ממך – אנחנו כאן.")
                : t("בוא נדבר ונבנה לך מערך קישורים שעובד בשבילך ולקוחותיך – בלי כאב ראש, בלי ספקים, בלי הפתעות.", "בואי נדבר ונבנה לך מערך קישורים שעובד בשבילך ולקוחותיך – בלי כאב ראש, בלי ספקים, בלי הפתעות.")}
              as="p"
              multiline
              styleable
              className="text-sm text-muted-foreground mt-1.5 leading-relaxed"
            />
          </div>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-3">
        <EditableText
          section="result"
          k={isDIY ? (isFemale ? "form_title_diy_f" : "form_title_diy_m") : (isFemale ? "form_title_managed_f" : "form_title_managed_m")}
          fallback={isDIY ? t("שלח לי את המדריך", "שלחי לי את המדריך") : t("קבע שיחת ייעוץ חינמית", "קבעי שיחת ייעוץ חינמית")}
          as="h4"
          styleable
          className="font-heading font-semibold text-base text-center mb-4 block"
        />

        <div className="grid grid-cols-2 gap-3">
          <Input
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder={getText("placeholder_name", "שם מלא")}
            className="bg-secondary border-border py-5"
          />
          <Input
            value={form.company}
            onChange={(e) => setForm({ ...form, company: e.target.value })}
            placeholder={getText("placeholder_company", "שם חברה / סוכנות")}
            className="bg-secondary border-border py-5"
          />
        </div>
        <Input
          required
          type="email"
          value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          placeholder={getText("placeholder_email", "אימייל")}
          className="bg-secondary border-border py-5"
        />
        <Input
          required
          type="tel"
          inputMode="tel"
          pattern="[0-9+\-\s()]*"
          value={form.phone}
          onChange={(e) => setForm({ ...form, phone: e.target.value })}
          placeholder={getText("placeholder_phone", "טלפון")}
          className="bg-secondary border-border py-5"
        />

        <Button
          type="submit"
          disabled={submitting}
          className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-heading font-semibold text-base py-6 rounded-xl shadow-[0_0_30px_hsl(174_72%_52%/0.25)] transition-all mt-2"
        >
          {submitting ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : isDIY ? (
            <>{getText(isFemale ? "submit_diy_f" : "submit_diy_m", t("שלח לי את המדריך", "שלחי לי את המדריך"))}</>
          ) : (
            <>
              {getText(isFemale ? "submit_managed_f" : "submit_managed_m", t("קבע שיחת ייעוץ", "קבעי שיחת ייעוץ"))}
              <ArrowLeft className="w-4 h-4 mr-2" />
            </>
          )}
        </Button>
        <EditableText
          section="result"
          k="disclaimer"
          fallback="לא נשלח ספאם. אף פעם."
          as="p"
          styleable
          className="text-xs text-muted-foreground text-center"
        />
      </form>
    </motion.div>
  );
}