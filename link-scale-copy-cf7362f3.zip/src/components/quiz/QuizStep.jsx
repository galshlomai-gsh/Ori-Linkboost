import React from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

export default function QuizStep({ question, answer, onAnswer, onNext }) {
  if (!question) return null;

  const handleOptionClick = (option) => {
    if (question.type === "multiple") {
      const currentAnswers = answer ? answer.split(", ") : [];
      const value = option.value || option.label;
      const updated = currentAnswers.includes(value)
        ? currentAnswers.filter((a) => a !== value)
        : [...currentAnswers, value];
      onAnswer(updated.join(", "), null);
    } else {
      onAnswer(option.value || option.label, option);
    }
  };

  const isSelected = (option) => {
    const val = option.value || option.label;
    if (question.type === "multiple") {
      return answer ? answer.split(", ").includes(val) : false;
    }
    return answer === val;
  };

  return (
    <motion.div
      key={question.id}
      initial={{ opacity: 0, x: 40 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -40 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="w-full"
      dir="rtl"
    >
      <h3 className="font-heading text-xl md:text-2xl font-bold mb-2 text-center">
        {question.title}
      </h3>
      {question.subtitle && (
        <p className="text-muted-foreground text-center mb-8 text-sm">
          {question.subtitle}
        </p>
      )}
      {!question.subtitle && <div className="mb-8" />}

      {question.type === "text" ? (
        <div className="max-w-md mx-auto space-y-4">
          <Input
            value={answer || ""}
            onChange={(e) => onAnswer(e.target.value, null)}
            placeholder="הקלד את התשובה..."
            className="bg-secondary border-border text-center text-lg py-6"
            dir="rtl"
          />
          <Button
            onClick={onNext}
            disabled={!answer}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-6"
          >
            המשך
          </Button>
        </div>
      ) : question.options?.some(o => o.image_url) ? (
        <div className="grid grid-cols-2 gap-4 max-w-lg mx-auto">
          {question.options?.map((option, i) => (
            <button
              key={i}
              onClick={() => handleOptionClick(option)}
              className={`rounded-2xl border overflow-hidden transition-all duration-200 text-center ${
                isSelected(option)
                  ? "border-primary shadow-lg shadow-primary/15 scale-[1.02]"
                  : "border-border/60 hover:border-primary/40"
              }`}
            >
              {option.image_url ? (
                <img src={option.image_url} alt={option.label} className="w-full h-36 object-cover" />
              ) : (
                <div className="w-full h-36 bg-secondary/60 flex items-center justify-center text-3xl">
                  {option.icon || "🖼"}
                </div>
              )}
              <div className={`px-3 py-2.5 flex items-center justify-between gap-2 ${
                isSelected(option) ? "bg-primary/10" : "bg-secondary/50"
              }`}>
                <span className="font-medium text-sm">{option.label}</span>
                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                  isSelected(option) ? "border-primary bg-primary" : "border-muted-foreground/30"
                }`}>
                  {isSelected(option) && <Check className="w-3 h-3 text-primary-foreground" />}
                </div>
              </div>
            </button>
          ))}
        </div>
      ) : (
        <div className="space-y-3 max-w-lg mx-auto">
          {question.options?.map((option, i) => (
            <button
              key={i}
              onClick={() => handleOptionClick(option)}
              className={`w-full p-4 rounded-xl border text-right transition-all duration-200 flex items-center gap-3 ${
                isSelected(option)
                  ? "border-primary bg-primary/10 text-foreground shadow-md shadow-primary/10"
                  : "border-border/60 bg-secondary/50 hover:border-primary/40 hover:bg-secondary text-foreground/80"
              }`}
            >
              <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                isSelected(option) ? "border-primary bg-primary" : "border-muted-foreground/30"
              }`}>
                {isSelected(option) && <Check className="w-3.5 h-3.5 text-primary-foreground" />}
              </div>
              {option.icon && <span className="text-lg">{option.icon}</span>}
              <span className="font-medium text-sm">{option.label}</span>
            </button>
          ))}
          {question.type === "multiple" && answer && (
            <Button
              onClick={onNext}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-6 mt-4"
            >
              המשך
            </Button>
          )}
        </div>
      )}
    </motion.div>
  );
}