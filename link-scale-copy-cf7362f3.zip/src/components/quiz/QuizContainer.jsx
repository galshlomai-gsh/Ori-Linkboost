import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { X, ChevronRight } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import QuizStep from "./QuizStep";
import ResultScreen from "./ResultScreen";

export default function QuizContainer({ open, onClose }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [classification, setClassification] = useState(null);
  const [gender, setGender] = useState(null); // "female" | "male" | null
  const [showResult, setShowResult] = useState(false);
  const [history, setHistory] = useState([0]);
  const containerRef = useRef(null);

  const { data: questions = [], isLoading } = useQuery({
    queryKey: ["quiz-questions"],
    queryFn: () => base44.entities.Question.filter({ is_active: true }, "order_index"),
    enabled: open,
  });

  useEffect(() => {
    if (open) {
      setCurrentIndex(0);
      setAnswers({});
      setClassification(null);
      setGender(null);
      setShowResult(false);
      setHistory([0]);
    }
  }, [open]);

  if (!open) return null;

  const currentQuestion = questions[currentIndex];
  const progress = questions.length > 0 ? ((currentIndex + 1) / questions.length) * 100 : 0;

  const goToNext = (selectedOption) => {
    // Check classification
    if (selectedOption?.classification) {
      setClassification(selectedOption.classification);
    }

    // Check if this is the final question or the classification question
    if (currentQuestion?.is_final || currentIndex >= questions.length - 1) {
      setShowResult(true);
      return;
    }

    // Check if jump to result directly
    if (selectedOption?.leads_to === "__result__") {
      setShowResult(true);
      return;
    }

    // Check conditional jump to specific question
    if (selectedOption?.leads_to) {
      const targetIdx = questions.findIndex((q) => q.id === selectedOption.leads_to);
      if (targetIdx !== -1) {
        setHistory([...history, targetIdx]);
        setCurrentIndex(targetIdx);
        return;
      }
    }

    const nextIdx = currentIndex + 1;
    setHistory([...history, nextIdx]);
    setCurrentIndex(nextIdx);
  };

  const handleAnswer = (value, option) => {
    if (!currentQuestion) return;
    setAnswers({ ...answers, [currentQuestion.id]: { question: currentQuestion.title, answer: value } });

    // Detect gender from option value
    if (option?.value === "female" || value === "מקדמת אתרים") {
      setGender("female");
    } else if (option?.value === "male" || value === "מקדם אתרים") {
      setGender("male");
    }

    // Auto-advance for buttons type
    if (currentQuestion.type === "buttons" && option) {
      setTimeout(() => goToNext(option), 300);
    }
  };

  const goBack = () => {
    if (showResult) {
      setShowResult(false);
      return;
    }
    if (history.length > 1) {
      const newHistory = [...history];
      newHistory.pop();
      setHistory(newHistory);
      setCurrentIndex(newHistory[newHistory.length - 1]);
    }
  };

  const handleLeadSubmit = async (form) => {
    const answersArr = Object.values(answers);
    const finalClassification = classification || "managed";
    await base44.entities.Lead.create({
      name: form.name,
      email: form.email,
      phone: form.phone,
      classification: finalClassification,
      status: "new",
      answers: answersArr,
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-background/95 backdrop-blur-xl flex items-center justify-center"
    >
      <div ref={containerRef} className="w-full max-w-2xl mx-auto px-4 py-8 relative">
        {/* Header */}
        <div className="flex items-center justify-between mb-8" dir="rtl">
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-secondary transition-colors">
            <X className="w-5 h-5 text-muted-foreground" />
          </button>
          {!showResult && (
            <div className="flex-1 mx-4">
              <Progress value={progress} className="h-1.5 bg-secondary" />
              <p className="text-xs text-muted-foreground mt-2 text-center">
                שאלה {currentIndex + 1} מתוך {questions.length}
              </p>
            </div>
          )}
          {history.length > 1 && (
            <button onClick={goBack} className="p-2 rounded-lg hover:bg-secondary transition-colors flex items-center gap-1 text-sm text-muted-foreground">
              חזור
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Content */}
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : showResult ? (
          <ResultScreen classification={classification} gender={gender} onSubmit={handleLeadSubmit} />
        ) : (
          <AnimatePresence mode="wait">
            {currentQuestion && (
              <QuizStep
                question={currentQuestion}
                answer={answers[currentQuestion.id]?.answer}
                onAnswer={handleAnswer}
                onNext={() => goToNext(null)}
              />
            )}
          </AnimatePresence>
        )}
      </div>
    </motion.div>
  );
}