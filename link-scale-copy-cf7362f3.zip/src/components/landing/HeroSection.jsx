import React from "react";
import { motion } from "framer-motion";
import EditableText from "@/components/inline-edit/EditableText";

const HERO_BG = "https://media.base44.com/images/public/69f8a490106785d4cf7362f3/278d94b2f_ChatGPTImageMay9202609_39_02PM.png";

export default function HeroSection() {
  return (
    <section id="hero" className="relative pt-28 pb-4 md:pb-6 px-4 overflow-hidden" dir="rtl">
      {/* Hero background image */}
      <div
        className="absolute inset-0 pointer-events-none bg-center bg-no-repeat bg-cover"
        style={{
          backgroundImage: `url('${HERO_BG}')`,
          opacity: 0.55
        }} />
      
      {/* Gradient overlays for readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/50 to-background pointer-events-none" />
      <div className="absolute inset-0 bg-background/30 pointer-events-none" />

      {/* Dot grid texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.06]"
        style={{
          backgroundImage: "radial-gradient(hsl(174 72% 52%) 1px, transparent 1px)",
          backgroundSize: "28px 28px"
        }} />
      

      {/* Ambient lights */}
      <div className="absolute top-1/3 right-1/4 w-[500px] h-[500px] bg-primary/8 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 w-[400px] h-[400px] bg-accent/6 rounded-full blur-[100px] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Centered hero content */}
        <div className="max-w-3xl mx-auto text-center pt-4 pb-2">

          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/8 mb-5 max-w-[92%]">
            
            <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse shrink-0" />
            <EditableText section="hero" k="badge_text" fallback="בדיקה חינמית למקדמי אתרים" styleable className="text-[10px] md:text-xs text-primary font-medium leading-tight" />
          </motion.div>

          {/* Pattern Interrupt */}
          






          

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-heading text-3xl md:text-5xl lg:text-[3.75rem] font-extrabold leading-[1.1] mb-4">
            
            <EditableText section="hero" k="headline_line1" fallback="לא נמאס לך לרדוף" styleable className="text-foreground" />
            <br />
            <EditableText section="hero" k="headline_line2" fallback="אחרי קישורים כל חודש?" styleable className="bg-gradient-to-l from-primary via-cyan-400 to-primary bg-clip-text text-transparent" />
          </motion.h1>
        </div>
      </div>
    </section>);

}