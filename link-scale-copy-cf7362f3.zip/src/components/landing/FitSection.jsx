import React from "react";
import { motion } from "framer-motion";
import { Check, X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import EditableText from "@/components/inline-edit/EditableText";

export default function FitSection({ onStartQuiz }) {
  const { data: items = [] } = useQuery({
    queryKey: ["fit_items"],
    queryFn: () => base44.entities.FitItem.filter({ is_active: true }, "order_index", 100),
    staleTime: 30000,
  });

  const fitItems = items.filter((i) => i.type === "fit");
  const unfitItems = items.filter((i) => i.type === "unfit");

  return (
    <section id="fit" className="relative py-20 px-4 overflow-hidden" dir="rtl">
      {/* Background ambient */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative z-10 max-w-6xl mx-auto">
        {/* Heading */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <EditableText section="fit" k="section_label" fallback="האם זה מתאים לך?" className="inline-block text-xs font-medium text-primary px-3 py-1 rounded-full border border-primary/30 bg-primary/10 mb-4" />
          <h2 className="font-heading text-3xl md:text-5xl font-extrabold mb-4">
            <EditableText section="fit" k="heading" fallback="השירות שלנו לא מתאים לכולם –" />
            <br />
            <EditableText section="fit" k="heading_highlight" fallback="ואנחנו גאים בזה" className="bg-gradient-to-l from-primary via-cyan-400 to-primary bg-clip-text text-transparent" />
          </h2>
          <EditableText as="p" multiline section="fit" k="subheading" fallback="אנחנו לא מנסים לעבוד עם כולם. בדוק אם אנחנו מתאימים זה לזה." className="text-sm md:text-base text-muted-foreground max-w-2xl mx-auto" />
        </motion.div>

        {/* Two columns */}
        <div className="grid md:grid-cols-2 gap-6 mb-12">
          {/* FIT */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="rounded-2xl border border-primary/30 bg-primary/5 p-6 md:p-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center">
                <Check className="w-5 h-5 text-primary" />
              </div>
              <EditableText as="h3" section="fit" k="fit_title" fallback="מתאים לך אם..." className="font-heading text-xl md:text-2xl font-bold text-primary" />
            </div>
            <ul className="space-y-3">
              {fitItems.map((item) => (
                <li key={item.id} className="flex items-start gap-3 text-sm md:text-base text-foreground/85">
                  <Check className="w-4 h-4 text-primary flex-shrink-0 mt-1" />
                  <span>{item.text}</span>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* NOT FIT */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="rounded-2xl border border-destructive/30 bg-destructive/5 p-6 md:p-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-destructive/15 border border-destructive/30 flex items-center justify-center">
                <X className="w-5 h-5 text-destructive" />
              </div>
              <EditableText as="h3" section="fit" k="unfit_title" fallback="לא מתאים לך אם..." className="font-heading text-xl md:text-2xl font-bold text-destructive" />
            </div>
            <ul className="space-y-3">
              {unfitItems.map((item) => (
                <li key={item.id} className="flex items-start gap-3 text-sm md:text-base text-foreground/85">
                  <X className="w-4 h-4 text-destructive flex-shrink-0 mt-1" />
                  <span>{item.text}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>

        {/* Winning sentence */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-6"
        >
          <EditableText
            as="p"
            multiline
            section="fit"
            k="winning_sentence"
            fallback="אם זיהית את עצמך ברשימת ה״מתאים״ – כדאי לנו מאוד לדבר."
            styleable
            className="text-lg md:text-2xl font-heading font-bold bg-gradient-to-l from-primary via-cyan-400 to-primary bg-clip-text text-transparent"
          />
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <Button
            onClick={onStartQuiz}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-heading font-semibold text-base px-8 py-6 rounded-xl"
            style={{ animation: "ctaPulse 3s ease-in-out infinite" }}
          >
            <EditableText section="fit" k="cta_button" fallback="בדוק אם אנחנו מתאימים" styleable />
          </Button>
        </motion.div>
      </div>
    </section>
  );
}