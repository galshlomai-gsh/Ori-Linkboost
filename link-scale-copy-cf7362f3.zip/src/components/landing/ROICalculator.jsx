import React, { useState, useMemo } from "react";
import { motion } from "framer-motion";
import { Clock, DollarSign, Calculator, TrendingUp, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSectionVisibility } from "@/hooks/useSectionVisibility";

export default function ROICalculator({ onStartQuiz }) {
  const { isVisible } = useSectionVisibility("roi");

  const [hourlyRate, setHourlyRate] = useState(150); // ₪ לשעה
  const [minutesPerLink, setMinutesPerLink] = useState(45); // דקות לקישור
  const [linksPerClient, setLinksPerClient] = useState(4); // קישורים ללקוח בחודש
  const [clients, setClients] = useState(8); // מספר לקוחות

  const { totalHours, totalCost } = useMemo(() => {
    const totalLinks = linksPerClient * clients;
    const totalMinutes = totalLinks * minutesPerLink;
    const hours = totalMinutes / 60;
    const cost = hours * hourlyRate;
    return {
      totalHours: hours,
      totalCost: cost,
    };
  }, [hourlyRate, minutesPerLink, linksPerClient, clients]);

  if (!isVisible) return null;

  const formatNumber = (n) =>
    new Intl.NumberFormat("he-IL", { maximumFractionDigits: 0 }).format(Math.round(n));

  const Field = ({ label, value, setValue, min, max, step, suffix, icon: Icon }) => (
    <div className="bg-card/40 border border-border/40 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
            <Icon className="w-4 h-4 text-primary" />
          </div>
          <label className="text-sm md:text-base font-medium text-foreground">{label}</label>
        </div>
        <div className="flex items-baseline gap-1">
          <span className="font-heading text-xl md:text-2xl font-bold text-primary">
            {formatNumber(value)}
          </span>
          <span className="text-xs text-muted-foreground">{suffix}</span>
        </div>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => setValue(Number(e.target.value))}
        className="w-full h-2 bg-secondary rounded-lg appearance-none cursor-pointer accent-primary"
      />
      <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
        <span>{min}</span>
        <span>{max}</span>
      </div>
    </div>
  );

  return (
    <section id="roi" className="relative py-16 px-4 bg-background overflow-hidden" dir="rtl">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border/60 to-transparent" />
      <div className="absolute top-20 right-1/4 w-96 h-96 bg-primary/4 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-1/4 w-80 h-80 bg-accent/4 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-5xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <span className="text-xs font-medium text-primary tracking-widest uppercase mb-2 block">
            <Calculator className="inline w-3 h-3 ml-1" />
            מחשבון עלות מול תועלת
          </span>
          <h2 className="font-heading text-2xl md:text-4xl font-bold mb-3 text-foreground">
            כמה זמן וכסף אתה מבזבז על בניית קישורים?
          </h2>
          <p className="text-sm md:text-base text-muted-foreground max-w-2xl mx-auto">
            הזז את המחוונים לפי הנתונים שלך – ותראה בדיוק כמה אתה יכול לחסוך כל חודש
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="grid md:grid-cols-2 gap-4 mb-6"
        >
          <Field
            label="עלות שעת עבודה שלך"
            value={hourlyRate}
            setValue={setHourlyRate}
            min={50}
            max={500}
            step={10}
            suffix="₪/שעה"
            icon={DollarSign}
          />
          <Field
            label="זמן לבניית קישור אחד"
            value={minutesPerLink}
            setValue={setMinutesPerLink}
            min={10}
            max={180}
            step={5}
            suffix="דקות"
            icon={Clock}
          />
          <Field
            label="קישורים ללקוח בחודש"
            value={linksPerClient}
            setValue={setLinksPerClient}
            min={1}
            max={20}
            step={1}
            suffix="קישורים"
            icon={TrendingUp}
          />
          <Field
            label="מספר לקוחות פעילים"
            value={clients}
            setValue={setClients}
            min={1}
            max={50}
            step={1}
            suffix="לקוחות"
            icon={Calculator}
          />
        </motion.div>

        {/* Result Block */}
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="relative rounded-2xl overflow-hidden border border-primary/30 bg-gradient-to-br from-primary/10 via-card to-accent/5 p-7 md:p-10"
        >
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-36 bg-primary/15 blur-3xl rounded-full pointer-events-none" />

          <div className="relative text-center mb-6">
            <p className="text-sm md:text-base text-muted-foreground mb-2">
              בכל חודש אתה משקיע על בניית קישורים:
            </p>
          </div>

          <div className="relative grid grid-cols-1 md:grid-cols-2 gap-4 mb-7">
            <div className="bg-background/60 border border-border/40 rounded-xl p-5 text-center">
              <Clock className="w-6 h-6 text-primary mx-auto mb-2" />
              <div className="font-heading text-3xl md:text-5xl font-extrabold text-primary mb-1">
                {formatNumber(totalHours)}
              </div>
              <div className="text-xs md:text-sm text-muted-foreground">שעות עבודה בחודש</div>
            </div>
            <div className="bg-background/60 border border-border/40 rounded-xl p-5 text-center">
              <DollarSign className="w-6 h-6 text-primary mx-auto mb-2" />
              <div className="font-heading text-3xl md:text-5xl font-extrabold text-primary mb-1">
                ₪{formatNumber(totalCost)}
              </div>
              <div className="text-xs md:text-sm text-muted-foreground">עלות הזמן שלך בחודש</div>
            </div>
          </div>

          <div className="relative text-center flex flex-col items-center gap-2">
            <p className="text-sm md:text-base text-foreground/85 mb-2 max-w-xl">
              את כל הזמן והכסף הזה אתה יכול להחזיר לעצמך – ולהשתמש בהם כדי לקחת עוד לקוחות ולגדול.
            </p>
            <Button
              onClick={onStartQuiz}
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground font-heading font-semibold text-base px-8 py-6 rounded-xl transition-all duration-300 hover:scale-[1.03]"
              style={{ animation: "ctaPulse 3s ease-in-out infinite" }}
            >
              <Zap className="w-4 h-4 ml-2 fill-primary-foreground" />
              בדוק איך נחסוך לך את הזמן הזה
            </Button>
            <p className="text-xs text-muted-foreground">2 דקות · ללא התחייבות</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}