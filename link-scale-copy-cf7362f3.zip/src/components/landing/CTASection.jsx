import React from "react";
import { motion } from "framer-motion";
import { Zap, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLandingContent } from "@/hooks/useLandingContent";
import EditableText from "@/components/inline-edit/EditableText";

const CHAIN_BG = "https://media.base44.com/images/public/69f8a490106785d4cf7362f3/06bd5ca9d_ChatGPTImageMay9202610_55_52PM.png";

export default function CTASection({ onStartQuiz }) {
  const { get } = useLandingContent("cta");

  return (
    <section id="cta" className="py-20 px-4 relative" dir="rtl">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border/60 to-transparent" />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="max-w-5xl mx-auto"
      >
        <div className="relative rounded-3xl overflow-hidden border border-primary/25 shadow-[0_0_60px_hsl(174_72%_52%/0.12)]">
          {/* Background image — chain illustration */}
          <div
            className="absolute inset-0 pointer-events-none bg-center bg-no-repeat bg-contain md:bg-cover"
            style={{
              backgroundImage: `url('${CHAIN_BG}')`,
              opacity: 0.7,
            }}
          />
          {/* Vignette gradient (centered readability) */}
          <div className="absolute inset-0 bg-background/60 pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/30 to-background/70 pointer-events-none" />
          {/* Top glow */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-72 h-36 bg-primary/15 blur-3xl rounded-full pointer-events-none" />

          <div className="relative z-10 p-8 md:p-12 max-w-3xl mx-auto text-center">
            <EditableText section="cta" k="section_label" fallback="מיועד למקדמי אתרים" styleable className="text-xs font-medium text-primary tracking-widest uppercase mb-3 block" />
            <h2 className="font-heading text-3xl md:text-4xl font-extrabold mb-3 leading-tight">
              <EditableText section="cta" k="headline_line1" fallback="תפסיק לנהל ספקים." styleable /><br />
              <EditableText section="cta" k="headline_line2" fallback="תתחיל לגדול." styleable className="text-primary" />
            </h2>
            <EditableText as="p" multiline section="cta" k="body" fallback="ענה על 6 שאלות קצרות ונבין יחד איפה אתה נמצא ואיך אנחנו יכולים לקחת ממך את כאב הראש הזה." styleable className="text-muted-foreground text-sm md:text-base mb-7 max-w-lg mx-auto leading-relaxed" />
            <div className="flex flex-col items-center gap-2">
              <Button
                onClick={onStartQuiz}
                size="lg"
                className="bg-primary hover:bg-primary/90 text-primary-foreground font-heading font-semibold text-base px-8 py-6 rounded-xl transition-all duration-300 hover:scale-[1.03]"
                style={{ animation: "ctaPulse 3s ease-in-out infinite" }}
              >
                <Zap className="w-4 h-4 ml-2 fill-primary-foreground" />
                <EditableText section="cta" k="button" fallback="בדיקה חינמית – 2 דקות" styleable />
                <ArrowLeft className="w-4 h-4 mr-2" />
              </Button>
              <EditableText as="p" section="cta" k="note" fallback="ללא התחייבות · מותאם לסוכנויות SEO ופרילנסרים" styleable className="text-xs text-muted-foreground" />
            </div>
          </div>
        </div>
      </motion.div>
    </section>
  );
}