import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Link2, Menu, X, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const NAV_LINKS = [
  { label: "ראשי", target: "hero" },
  { label: "למה אנחנו", target: "objection" },
  { label: "סיפורי הצלחה", target: "testimonials" },
  { label: "שירותים", target: "benefits" },
  { label: "צור קשר", target: "cta" },
];

export default function StickyNav({ onStartQuiz }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTo = (id) => {
    setOpen(false);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <motion.nav
      initial={{ y: -40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.4 }}
      dir="rtl"
      className={`fixed top-0 inset-x-0 z-40 transition-all duration-300 ${
        scrolled
          ? "bg-background/75 backdrop-blur-xl border-b border-primary/10 shadow-[0_4px_24px_rgba(0,0,0,0.4)]"
          : "bg-background/30 backdrop-blur-md border-b border-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-6 h-14 flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={() => scrollTo("hero")}
          className="flex items-center gap-2 group"
        >
          <div className="w-7 h-7 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center group-hover:bg-primary/25 transition-colors">
            <Link2 className="w-4 h-4 text-primary" />
          </div>
          <span className="font-heading font-bold text-base text-foreground">LinkBoost</span>
        </button>

        {/* Desktop menu */}
        <div className="hidden md:flex items-center gap-1">
          {NAV_LINKS.map((l) => (
            <button
              key={l.target}
              onClick={() => scrollTo(l.target)}
              className="px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md hover:bg-secondary/40"
            >
              {l.label}
            </button>
          ))}
        </div>

        {/* CTA */}
        <div className="flex items-center gap-2">
          <Button
            onClick={onStartQuiz}
            size="sm"
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold h-9 px-4 text-sm shadow-[0_0_20px_hsl(174_72%_52%/0.35)] hover:shadow-[0_0_32px_hsl(174_72%_52%/0.55)] transition-all"
          >
            <Zap className="w-3.5 h-3.5 ml-1 fill-primary-foreground" />
            בדיקה חינמית
          </Button>
          <button
            onClick={() => setOpen((v) => !v)}
            className="md:hidden p-2 rounded-md hover:bg-secondary/40 text-foreground"
            aria-label="Menu"
          >
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden border-t border-primary/10 bg-background/95 backdrop-blur-xl">
          <div className="px-4 py-3 flex flex-col gap-1">
            {NAV_LINKS.map((l) => (
              <button
                key={l.target}
                onClick={() => scrollTo(l.target)}
                className="text-right py-2 px-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md"
              >
                {l.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </motion.nav>
  );
}