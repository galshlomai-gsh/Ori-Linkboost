import React from "react";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";
import { useInlineEdit } from "@/components/inline-edit/InlineEditContext";
import { CustomSectionCard, EditableField } from "@/components/landing/CustomSectionRenderer";
import EditableText from "@/components/inline-edit/EditableText";
import { useLandingContent } from "@/hooks/useLandingContent";

/**
 * Groups multiple "customer_story" CustomSections into a single visual section,
 * using ONE shared header (taken from the first story) and a "או על" divider between stories.
 */
export default function CustomerStoriesGroup({ sections }) {
  const { enabled } = useInlineEdit();
  const { get } = useLandingContent("customer_stories");
  if (!sections || sections.length === 0) return null;

  const headerSection = sections[0];

  return (
    <section className="relative py-16 md:py-20 px-4 overflow-hidden" dir="rtl">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative z-10 max-w-4xl mx-auto">
        {/* Shared header from the first story */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          {(headerSection.badge || enabled) && (
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/10 mb-5">
              <Sparkles className="w-3.5 h-3.5 text-primary" />
              <EditableField section={headerSection} field="badge" fallback="סיפורי לקוחות" />
            </div>
          )}

          <h2 className="mb-4">
            <EditableField section={headerSection} field="heading" fallback="תנו לנו לספר לכם על..." />
            {(headerSection.heading_highlight || enabled) && (
              <>
                {" "}
                <EditableField section={headerSection} field="heading_highlight" fallback="הלקוחות שלנו" />
              </>
            )}
          </h2>

          {(headerSection.subheading || enabled) && (
            <EditableField as="p" section={headerSection} field="subheading" fallback="תת-כותרת..." extraClassName="mx-auto" />
          )}
        </motion.div>

        {/* Cards — for the 2nd+ story, show "או על [שם]" heading instead of the main heading */}
        <div className="space-y-10">
          {sections.map((s, i) => (
            <React.Fragment key={s.id}>
              {i > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                  className="text-center"
                >
                  <h2 className="mb-4">
                    <EditableText
                      section="customer_stories"
                      k="secondary_prefix"
                      fallback={get("secondary_prefix", "או על")}
                      className="font-heading text-3xl md:text-5xl font-extrabold leading-[1.15] text-foreground"
                    />
                    {" "}
                    <EditableField section={s} field="heading_highlight" fallback="שם הלקוח" />
                  </h2>
                  {(s.subheading || enabled) && (
                    <EditableField as="p" section={s} field="subheading" fallback="תת-כותרת..." extraClassName="mx-auto" />
                  )}
                </motion.div>
              )}
              <CustomSectionCard section={s} />
            </React.Fragment>
          ))}
        </div>
      </div>
    </section>
  );
}