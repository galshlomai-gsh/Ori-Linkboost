import React from "react";
import { motion } from "framer-motion";
import { Link2, Clock, TrendingUp, Shield, Users, BarChart3, Zap } from "lucide-react";
import { useLandingContent } from "@/hooks/useLandingContent";
import { Button } from "@/components/ui/button";
import EditableText from "@/components/inline-edit/EditableText";

const ICONS = [Link2, Clock, TrendingUp, Shield, Users, BarChart3];

export default function BenefitsSection({ onStartQuiz }) {
  const { get } = useLandingContent("benefits");

  const benefits = [1, 2, 3, 4, 5, 6].map((n, i) => ({
    icon: ICONS[i],
    title: get(`card${n}_title`, ""),
    desc: get(`card${n}_desc`, ""),
  }));

  return (
    <section id="benefits" className="py-20 px-4 relative" dir="rtl">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border/60 to-transparent" />
      <div className="absolute top-40 left-10 w-72 h-72 bg-primary/4 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <EditableText section="benefits" k="section_label" fallback="למה מקדמים בוחרים בנו" styleable className="text-base md:text-base font-semibold text-primary tracking-wide mb-3 block" />
          <EditableText as="h2" section="benefits" k="heading" fallback="הפתרון לבניית קישורים בסקייל" styleable className="font-heading text-2xl md:text-4xl font-bold mb-3" />
          <EditableText as="p" multiline section="benefits" k="subheading" fallback="תפסיק לבזבז זמן על ספקים ומעקבים. תתמקד בלגדול." styleable className="text-muted-foreground text-base md:text-base max-w-xl mx-auto" />
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {benefits.map((b, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              className="group relative p-5 rounded-xl bg-gradient-to-br from-card to-card/40 border border-border/40 hover:border-primary/40 transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_8px_32px_hsl(174_72%_52%/0.12)] overflow-hidden"
            >
              {/* Glass texture */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-br from-primary/8 via-transparent to-accent/4 pointer-events-none" />
              {/* Top accent on hover */}
              <div className="absolute top-0 right-0 left-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

              <div className="relative flex items-start justify-between mb-3">
                <EditableText as="h3" section="benefits" k={`card${i + 1}_title`} fallback={b.title} styleable className="font-heading font-semibold text-base text-foreground leading-snug flex-1 pr-3" />
                <div className="w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center group-hover:bg-primary/20 transition-colors flex-shrink-0">
                  <b.icon className="w-4 h-4 text-primary" />
                </div>
              </div>
              <EditableText as="p" multiline section="benefits" k={`card${i + 1}_desc`} fallback={b.desc} styleable className="relative text-muted-foreground text-sm leading-relaxed" />
            </motion.div>
          ))}
        </div>

        {/* Repeated CTA after benefits */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
          className="mt-12 text-center flex flex-col items-center gap-2"
        >
          <Button
            onClick={onStartQuiz}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-heading font-semibold text-base px-8 py-6 rounded-xl transition-all duration-300 hover:scale-[1.03]"
            style={{ animation: "ctaPulse 3s ease-in-out infinite" }}
          >
            <Zap className="w-4 h-4 ml-2 fill-primary-foreground" />
            התחל ניתוח SEO חינם · 2 דקות
          </Button>
          <p className="text-xs text-muted-foreground">ללא התחייבות. מותאם לסוכנויות SEO ופרילנסרים.</p>
        </motion.div>
      </div>
    </section>
  );
}