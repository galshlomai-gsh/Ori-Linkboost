import React from "react";
import { motion } from "framer-motion";
import { Search, Cog, TrendingUp } from "lucide-react";
import EditableText from "@/components/inline-edit/EditableText";

/**
 * "איך זה עובד" — 3 steps presented as elegant cards side by side.
 * All texts are editable (section="how").
 */
const STEPS = [
  {
    icon: Search,
    numKey: "step1_num",
    numFallback: "01",
    titleKey: "step1_title",
    titleFallback: "ניתוח ראשוני של האתר",
    bodyKey: "step1_body",
    bodyFallback: "אנחנו בודקים את פרופיל הקישורים הקיים, מאתרים פערים מול המתחרים ובונים אסטרטגיה מותאמת.",
  },
  {
    icon: Cog,
    numKey: "step2_num",
    numFallback: "02",
    titleKey: "step2_title",
    titleFallback: "בנייה ושיווץ הקישורים",
    bodyKey: "step2_body",
    bodyFallback: "הצוות שלנו מאתר אתרים איכותיים, מבצע outreach ומשבץ קישורים רלוונטיים – בלי שתצטרך לגעת.",
  },
  {
    icon: TrendingUp,
    numKey: "step3_num",
    numFallback: "03",
    titleKey: "step3_title",
    titleFallback: "דוחות ותוצאות",
    bodyKey: "step3_body",
    bodyFallback: "מקבלים דוח חודשי שקוף עם כל הקישורים, מדדים ושיפור בדירוגים – ואתה ממשיך לסקייל.",
  },
];

function StepCard({ step, index }) {
  const Icon = step.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.55, delay: index * 0.12 }}
      className="group relative rounded-2xl border border-primary/20 bg-gradient-to-br from-card/80 via-card/60 to-card/40 backdrop-blur-sm p-7 md:p-8 hover:border-primary/50 hover:-translate-y-1 transition-all duration-300 overflow-hidden"
    >
      {/* Step number watermark */}
      <div className="absolute top-3 left-4 font-heading text-6xl md:text-7xl font-extrabold text-primary/10 group-hover:text-primary/20 transition-colors leading-none select-none">
        <EditableText section="how" k={step.numKey} fallback={step.numFallback} />
      </div>

      {/* Icon */}
      <div className="relative w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/25 to-primary/10 border border-primary/30 flex items-center justify-center mb-5 shadow-lg shadow-primary/10">
        <Icon className="w-7 h-7 text-primary" />
      </div>

      {/* Title */}
      <EditableText
        section="how"
        k={step.titleKey}
        fallback={step.titleFallback}
        as="h3"
        styleable
        className="relative font-heading text-xl md:text-2xl font-bold text-foreground mb-3 leading-tight"
      />

      {/* Body */}
      <EditableText
        section="how"
        k={step.bodyKey}
        fallback={step.bodyFallback}
        as="p"
        multiline
        styleable
        className="relative text-sm md:text-base text-muted-foreground leading-relaxed"
      />

      {/* Bottom accent */}
      <div className="absolute bottom-0 right-0 left-0 h-1 bg-gradient-to-l from-transparent via-primary/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
    </motion.div>
  );
}

export default function HowItWorksSection() {
  return (
    <section id="how" className="relative py-20 px-4 overflow-hidden" dir="rtl">
      {/* Background ambient */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 right-1/4 w-96 h-96 bg-primary/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-20 left-1/4 w-80 h-80 bg-accent/5 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto">
        {/* Heading */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <div className="mb-4">
            <EditableText
              section="how"
              k="badge"
              fallback="איך זה עובד"
              as="span"
              styleable
              className="inline-block text-xs font-medium text-primary tracking-widest uppercase px-3 py-1 rounded-full border border-primary/30 bg-primary/10"
            />
          </div>
          <EditableText
            section="how"
            k="heading"
            fallback="3 צעדים פשוטים לקישורים איכותיים"
            as="h2"
            styleable
            className="font-heading text-3xl md:text-5xl font-extrabold mb-4 text-foreground"
          />
          <EditableText
            section="how"
            k="subheading"
            fallback="תהליך מסודר, שקוף ומדיד – מבדיקה ראשונית ועד דוח חודשי"
            as="p"
            multiline
            styleable
            className="text-sm md:text-base text-muted-foreground max-w-2xl mx-auto"
          />
        </motion.div>

        {/* 3 Steps Grid */}
        <div className="grid md:grid-cols-3 gap-5 md:gap-6">
          {STEPS.map((step, i) => (
            <StepCard key={step.numKey} step={step} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}