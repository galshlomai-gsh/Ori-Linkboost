import React, { useMemo } from "react";
import { motion } from "framer-motion";
import { Clock, TrendingUp, Zap, Cog, Quote } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import EditableText from "@/components/inline-edit/EditableText";

const ICON_MAP = { Clock, TrendingUp, Zap, Cog };

const COLOR_MAP = {
  blue: {
    border: "border-blue-500/30",
    bg: "from-blue-500/10 to-blue-500/[0.03]",
    iconColor: "text-blue-400",
    badge: "bg-blue-500/15 text-blue-300 border-blue-500/30",
    quote: "text-blue-400/70",
  },
  emerald: {
    border: "border-emerald-500/30",
    bg: "from-emerald-500/10 to-emerald-500/[0.03]",
    iconColor: "text-emerald-400",
    badge: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
    quote: "text-emerald-400/70",
  },
  yellow: {
    border: "border-yellow-500/30",
    bg: "from-yellow-500/10 to-yellow-500/[0.03]",
    iconColor: "text-yellow-400",
    badge: "bg-yellow-500/15 text-yellow-300 border-yellow-500/30",
    quote: "text-yellow-400/70",
  },
  purple: {
    border: "border-purple-500/30",
    bg: "from-purple-500/10 to-purple-500/[0.03]",
    iconColor: "text-purple-400",
    badge: "bg-purple-500/15 text-purple-300 border-purple-500/30",
    quote: "text-purple-400/70",
  },
  primary: {
    border: "border-primary/30",
    bg: "from-primary/10 to-primary/[0.03]",
    iconColor: "text-primary",
    badge: "bg-primary/15 text-primary border-primary/30",
    quote: "text-primary/70",
  },
};

const DEFAULT_TESTIMONIALS = [
  {
    id: "default-1",
    icon_name: "Clock",
    title: "חסך לי שעות עבודה כל שבוע",
    text: "הפסקתי להתעסק עם ספקים, מיקוחים ובדיקות. העברתי הכל אליהם – ואני פשוט מקבל קישורים מוכנים. זה שחרר לי לפחות 10 שעות בשבוע.",
    badge: "↓ 10+ שעות בשבוע נחסכו",
    author: "עידו כהן",
    role: "בעל סוכנות SEO",
    color_scheme: "emerald",
  },
  {
    id: "default-2",
    icon_name: "TrendingUp",
    title: "אתרך לוף יציבות בקישורים",
    text: "לפני זה כל חודש היה נראה אחרת – ספקים, איכות, כאב ראש. היום יש לי תהליך קבוע, איכותי ויציב לכל הלקוחות.",
    badge: "יציבות מלאה בתהליך",
    author: "תומר לוי",
    role: "Head of SEO",
    color_scheme: "blue",
  },
  {
    id: "default-3",
    icon_name: "Zap",
    title: "הצלחתי לגדיל בלי להגדיל צוות",
    text: "לקחתי עוד לקוחות בלי לחשוב פעמיים. אני לא צריך לגייס עובדים או לנהל עוד אנשים – הם פשוט עושים את זה בשבילי.",
    badge: "סקייל בלי גיוס עובדים",
    author: "שירה בן דוד",
    role: "מנהלת סוכנות",
    color_scheme: "purple",
  },
  {
    id: "default-4",
    icon_name: "Cog",
    title: "זה פשוט נהיה plug & play",
    text: "אני שולח אתר – ומקבל קישורים. בלי לחסביר, בלי לרדוף, בלי לבדוק עוד דבר. זה נהיה חלק שקט בעסק.",
    badge: "עובד בלי כאב ראש",
    author: "אורן מזרחי",
    role: "מקדם אתרים",
    color_scheme: "yellow",
  },
];

function TestimonialCard({ t, delay }) {
  const palette = COLOR_MAP[t.color_scheme] || COLOR_MAP.primary;
  const IconComponent = ICON_MAP[t.icon_name] || Zap;

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay }}
      className={`relative rounded-2xl border ${palette.border} bg-gradient-to-br ${palette.bg} p-6 md:p-7 backdrop-blur-sm`}
    >
      {/* Quote icon decoration */}
      <Quote className={`absolute top-5 right-5 w-7 h-7 ${palette.quote} fill-current opacity-60`} strokeWidth={0} />

      {/* Title */}
      <h3 className="font-heading text-lg md:text-xl font-bold text-foreground mb-3 pl-12 pt-6 leading-tight">
        {t.title}
      </h3>

      {/* Body */}
      <p className="text-sm text-foreground/80 mb-5 leading-relaxed">
        "{t.text}"
      </p>

      {/* Badge */}
      {t.badge && (
        <div className={`inline-block mb-5 px-3 py-1.5 rounded-md border ${palette.badge} font-semibold text-xs`}>
          {t.badge}
        </div>
      )}

      {/* Divider */}
      <div className="h-px bg-border/30 mb-4" />

      {/* Author */}
      <div className="text-right">
        <div className="font-bold text-sm text-foreground">{t.author}</div>
        {t.role && <div className="text-xs text-muted-foreground mt-0.5">{t.role}</div>}
      </div>
    </motion.div>
  );
}

export default function TestimonialsSection({ onStartQuiz }) {
  const { data: fetched = [] } = useQuery({
    queryKey: ["testimonials-public"],
    queryFn: () => base44.entities.Testimonial.filter({ is_active: true }, "order_index"),
    staleTime: 30 * 1000,
  });

  const testimonials = useMemo(
    () => (fetched && fetched.length > 0 ? fetched : DEFAULT_TESTIMONIALS),
    [fetched]
  );

  if (testimonials.length === 0) return null;

  return (
    <section id="testimonials" className="relative py-16 px-4 bg-background overflow-hidden" dir="rtl">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-20 right-10 w-96 h-96 bg-primary/3 rounded-full blur-3xl" />
        <div className="absolute bottom-10 left-20 w-80 h-80 bg-accent/3 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <div className="mb-3">
            <EditableText
              section="testimonials"
              k="badge"
              fallback="סיפורי הצלחה"
              as="span"
              styleable
              className="inline-block text-xs font-medium text-primary tracking-widest uppercase px-3 py-1 rounded-full border border-primary/30 bg-primary/10"
            />
          </div>
          <EditableText
            section="testimonials"
            k="headline"
            fallback="מקדמי אתרים שעברו ל-Outsource – ולא חזרו אחורה"
            as="h2"
            styleable
            className="font-heading text-2xl md:text-4xl font-bold mb-3 text-foreground"
          />
          <EditableText
            section="testimonials"
            k="subheadline"
            fallback="סוכנויות ואנשי SEO שכבר הפסיקו לבנות קישורים בעצמם – ומתרכזים בצמיחה"
            as="p"
            styleable
            className="text-sm md:text-base text-muted-foreground max-w-3xl mx-auto"
          />
        </motion.div>

        {/* 2x2 Grid */}
        <div className="grid md:grid-cols-2 gap-5 mb-12">
          {testimonials.map((t, i) => (
            <TestimonialCard key={t.id || i} t={t} delay={i * 0.08} />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center bg-gradient-to-r from-primary/10 via-accent/5 to-primary/10 rounded-2xl border border-primary/20 p-7 md:p-10"
        >
          <EditableText
            section="testimonials"
            k="cta_headline"
            fallback="רוצה גם להפסיק להתעסק עם קישורים?"
            as="h3"
            styleable
            className="font-heading text-2xl md:text-4xl font-bold text-foreground mb-2"
          />
          <EditableText
            section="testimonials"
            k="cta_subheadline"
            fallback="בדוק אם זה מתאים לך תוך 2 דקות ללא התחייבות"
            as="p"
            styleable
            className="text-sm md:text-base text-muted-foreground mb-5 max-w-2xl mx-auto"
          />
          <Button
            onClick={onStartQuiz}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold px-7 py-6 text-sm md:text-base shadow-lg shadow-primary/30"
          >
            <EditableText section="testimonials" k="cta_button" fallback="בואו נראה מה מתאים לך" />
          </Button>
        </motion.div>
      </div>
    </section>
  );
}