import React from "react";
import { motion } from "framer-motion";
import { AlertCircle } from "lucide-react";
import { useLandingContent } from "@/hooks/useLandingContent";
import EditableItem from "@/components/inline-edit/EditableItem";
import { FIELD_STYLES } from "@/components/inline-edit/fieldStyles";
import { renderRichText } from "@/lib/renderRichText";

// Style prefixes — keep in sync with STYLE_OPTIONS in AdminLandingContent
const STYLE_PREFIXES = ["heading", "sub_body", "body", "badge", "note"];

function detectStyle(key) {
  if (!key) return "body";
  const sorted = [...STYLE_PREFIXES].sort((a, b) => b.length - a.length);
  return sorted.find((p) => key === p || key.startsWith(p + "_")) || "body";
}

// Default class names per legacy prefix (used in view mode when no inline style override exists)
function defaultClassFor(style) {
  switch (style) {
    case "heading":
      return "font-heading text-3xl md:text-5xl font-extrabold leading-[1.15] text-foreground text-center whitespace-pre-line block";
    case "sub_body":
      return "text-sm md:text-base text-muted-foreground leading-relaxed whitespace-pre-line text-center block";
    case "note":
      return "text-xs text-muted-foreground text-center whitespace-pre-line block";
    case "body":
    default:
      return "text-base md:text-xl text-foreground/90 leading-relaxed whitespace-pre-line text-center block";
  }
}

// Get the chosen inline-edit style key for an item, if any.
function getStyleOverride(items, key) {
  const styleItem = items.find((d) => d.key === `${key}__style`);
  return styleItem?.value || null;
}

function ItemRenderer({ item, allItems }) {
  const legacyStyle = detectStyle(item.key);
  const override = getStyleOverride(allItems, item.key);

  // Badge is special — keep its decorative wrapper (icon + pill)
  if (legacyStyle === "badge" && !override) {
    if (!item.value) return null;
    return (
      <div className="flex justify-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-destructive/30 bg-destructive/10">
          <AlertCircle className="w-3.5 h-3.5 text-destructive" />
          <EditableItem
            item={item}
            as="span"
            styleable
            className="text-xs text-destructive font-medium"
          >
            {renderRichText(item.value)}
          </EditableItem>
        </div>
      </div>
    );
  }

  // Pick className: use override's preset (if set) or fall back to legacy class
  const baseClass = override && FIELD_STYLES[override]
    ? `${FIELD_STYLES[override].className} text-center block`
    : defaultClassFor(legacyStyle);

  return (
    <EditableItem
      item={item}
      as="div"
      multiline
      styleable
      className={baseClass}
    >
      {renderRichText(item.value)}
    </EditableItem>
  );
}

export default function PainSection() {
  const { items } = useLandingContent("pain");

  // Hide style-meta rows from rendering (they're handled by EditableItem itself)
  const visible = items.filter((it) => !it.key.endsWith("__style"));
  const sorted = [...visible].sort((a, b) => (a.order_index ?? 0) - (b.order_index ?? 0));

  // Group into segments: headings & badges render standalone (outside card);
  // body / sub_body / note group into a single card.
  const segments = [];
  let currentCard = null;
  for (const item of sorted) {
    const style = detectStyle(item.key);
    if (style === "heading" || style === "badge") {
      currentCard = null;
      segments.push({ type: "standalone", item });
    } else {
      if (!currentCard) {
        currentCard = { type: "card", items: [] };
        segments.push(currentCard);
      }
      currentCard.items.push(item);
    }
  }

  return (
    <section id="pain" className="relative pt-4 pb-12 md:pt-6 md:pb-16 px-4 overflow-hidden" dir="rtl">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-destructive/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative z-10 max-w-4xl mx-auto space-y-6 text-center">
        {segments.map((seg, idx) => {
          if (seg.type === "standalone") {
            return (
              <motion.div
                key={`s-${seg.item.id}`}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <ItemRenderer item={seg.item} allItems={items} />
              </motion.div>
            );
          }
          return (
            <motion.div
              key={`c-${idx}`}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="space-y-4"
            >
              {seg.items.map((item) => (
                <ItemRenderer key={item.id} item={item} allItems={items} />
              ))}
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}