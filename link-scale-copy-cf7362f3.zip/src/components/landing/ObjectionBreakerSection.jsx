import React from "react";
import { motion } from "framer-motion";
import { FileText, PenTool, Users, Link as LinkIcon } from "lucide-react";
import EditableText from "@/components/inline-edit/EditableText";

const analogies = [
  {
    icon: FileText,
    keyBase: "card1",
    titleFallback: "אתה לא אוסף חשבוניות בעצמך",
    descFallback: "יש לך הנהלת חשבונות",
    reasonFallback: "כי הזמן שלך שווה יותר",
    tint: {
      border: "border-emerald-500/25 hover:border-emerald-400/60",
      bg: "from-emerald-500/10 via-card/60 to-card/40",
      iconWrap: "from-emerald-500/25 to-emerald-500/10 border-emerald-500/30 shadow-emerald-500/10",
      iconColor: "text-emerald-400",
      reason: "text-emerald-400/80",
      accent: "via-emerald-400/40",
    },
  },
  {
    icon: PenTool,
    keyBase: "card2",
    titleFallback: "אתה לא כותב את כל התוכן בעצמך",
    descFallback: "יש לך כותבי תוכן",
    reasonFallback: "כי זה לא הפוקוס שלך",
    tint: {
      border: "border-purple-500/25 hover:border-purple-400/60",
      bg: "from-purple-500/10 via-card/60 to-card/40",
      iconWrap: "from-purple-500/25 to-purple-500/10 border-purple-500/30 shadow-purple-500/10",
      iconColor: "text-purple-400",
      reason: "text-purple-400/80",
      accent: "via-purple-400/40",
    },
  },
  {
    icon: Users,
    keyBase: "card3",
    titleFallback: "אתה לא מנהל כל משימה קטנה בעסק",
    descFallback: "יש לך צוות / עוזרים",
    reasonFallback: "כי אתה צריך לחשוב על צמיחה",
    tint: {
      border: "border-amber-500/25 hover:border-amber-400/60",
      bg: "from-amber-500/10 via-card/60 to-card/40",
      iconWrap: "from-amber-500/25 to-amber-500/10 border-amber-500/30 shadow-amber-500/10",
      iconColor: "text-amber-400",
      reason: "text-amber-400/80",
      accent: "via-amber-400/40",
    },
  },
];

export default function ObjectionBreakerSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5, ease: "easeOut" }
    }
  };

  return (
    <section id="objection" className="relative py-16 px-4 bg-background overflow-hidden" dir="rtl">
      {/* Background decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-10 right-10 w-72 h-72 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
          className="text-center mb-10">

          <EditableText
            section="objection"
            k="headline"
            fallback="אתה לא אמור לבנות קישורים בעצמך"
            as="h2"
            styleable
            className="font-heading text-2xl md:text-4xl font-bold mb-3 text-foreground"
          />
          <EditableText
            section="objection"
            k="subheadline"
            fallback="בדיוק כמו שיש דברים אחרים שכבר מזמן הפסקת לעשות לבד"
            as="p"
            styleable
            className="text-sm md:text-base text-muted-foreground max-w-2xl mx-auto"
          />
        </motion.div>

        {/* Analogies Grid - Top 3 */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">

          {analogies.map((analogy, idx) => {
            const IconComponent = analogy.icon;
            const t = analogy.tint;
            return (
              <motion.div
                key={idx}
                variants={itemVariants}
                className={`group relative rounded-2xl border ${t.border} bg-gradient-to-br ${t.bg} backdrop-blur-sm hover:-translate-y-1 transition-all duration-300 overflow-hidden`}>

                <div className="relative p-6 md:p-7 flex flex-col items-center text-center">
                  <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${t.iconWrap} border flex items-center justify-center mb-4 shadow-lg`}>
                    <IconComponent className={`w-6 h-6 ${t.iconColor}`} />
                  </div>
                  <EditableText
                    section="objection"
                    k={`${analogy.keyBase}_title`}
                    fallback={analogy.titleFallback}
                    as="h3"
                    styleable
                    className="font-heading font-bold text-lg md:text-xl mb-2 leading-tight text-foreground"
                  />
                  <EditableText
                    section="objection"
                    k={`${analogy.keyBase}_desc`}
                    fallback={analogy.descFallback}
                    as="p"
                    styleable
                    className="text-muted-foreground text-sm mb-4 leading-relaxed"
                  />
                  <div className="pt-3 border-t border-border/30 w-full">
                    <EditableText
                      section="objection"
                      k={`${analogy.keyBase}_reason`}
                      fallback={analogy.reasonFallback}
                      as="div"
                      styleable
                      className={`text-xs font-medium ${t.reason}`}
                    />
                  </div>
                </div>

                {/* Bottom accent */}
                <div className={`absolute bottom-0 right-0 left-0 h-1 bg-gradient-to-l from-transparent ${t.accent} to-transparent opacity-0 group-hover:opacity-100 transition-opacity`} />
              </motion.div>);

          })}
        </motion.div>

        {/* Warning Block - Center */}
        <motion.div
          variants={itemVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="flex justify-center mb-8">

          <div
            className="relative rounded-2xl border-2 transition-all duration-300 overflow-hidden group w-full max-w-3xl bg-gradient-to-br from-red-500/25 to-red-500/8 border-red-500/60"
            style={{ animation: "redGlowPulse 1.8s ease-in-out infinite" }}>

            <div className="absolute inset-0 opacity-25 group-hover:opacity-40 transition-opacity duration-300 bg-red-500/10" />
            <div className="absolute -top-2 -right-2 w-32 h-32 bg-red-500/30 rounded-full blur-3xl animate-pulse" />
            <div className="absolute -bottom-2 -left-2 w-32 h-32 bg-red-500/20 rounded-full blur-3xl animate-pulse" />

            <div className="relative p-8 md:p-10">
              <div className="flex items-center justify-center gap-4">
                <div className="p-3 md:p-4 rounded-xl flex-shrink-0 bg-red-500/25 border border-red-500/40 flex items-center justify-center">
                  <LinkIcon className="w-7 h-7 md:w-8 md:h-8 text-red-400" />
                </div>
                <div className="flex-1 min-w-0 flex items-center justify-center">
                  <EditableText
                    section="objection"
                    k="warning_title"
                    fallback="אז למה אתה עדיין בונה קישורים בעצמך?"
                    as="h3"
                    styleable
                    className="font-heading font-extrabold text-2xl md:text-4xl leading-tight text-red-400 text-center drop-shadow-[0_0_12px_rgba(239,68,68,0.5)] m-0"
                  />
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>);

}