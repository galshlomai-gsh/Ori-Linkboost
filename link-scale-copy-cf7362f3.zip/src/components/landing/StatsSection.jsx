import React from "react";
import { motion } from "framer-motion";
import { Zap, Shield, Globe2, Users, Link2, TrendingUp, Award, Calendar, Database, CheckCircle } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useLandingContent } from "@/hooks/useLandingContent";

const STAT_ICON_MAP = { Link2, Users, Globe2, Shield, TrendingUp, Award, Calendar, Database, Zap, CheckCircle };

/**
 * StatsSection — the stats bar (previously embedded inside HeroSection).
 * Content is stored under the "hero" section keys to preserve existing data.
 */
export default function StatsSection() {
  const { get } = useLandingContent("hero");

  const { data: fetchedStats = [] } = useQuery({
    queryKey: ["stats_public"],
    queryFn: () => base44.entities.Stat.filter({ is_active: true }, "order_index", 100),
    staleTime: 30000,
  });

  const FALLBACK_STATS = [
    { icon_name: "Shield", value: get("stats_retention", "98%"), label: get("stats_retention_label", "שימור לקוחות") },
    { icon_name: "Globe2", value: get("stats_sites", "340+"), label: get("stats_sites_label", "אתרים מנוהלים") },
    { icon_name: "Users", value: get("stats_agencies", "120+"), label: get("stats_agencies_label", "מקדמים וסוכנויות") },
    { icon_name: "Link2", value: get("stats_links", "2,400+"), label: get("stats_links_label", "קישורים נבנו") },
  ];

  const stats = (fetchedStats.length > 0 ? fetchedStats : FALLBACK_STATS).map((s) => ({
    icon: STAT_ICON_MAP[s.icon_name] || Link2,
    value: s.value,
    label: s.label,
  }));

  return (
    <section id="stats" className="relative px-4 pb-10" dir="rtl">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-3 max-w-5xl mx-auto"
      >
        {stats.map((s, i) => {
          const Icon = s.icon;
          return (
            <div
              key={i}
              className="flex items-center gap-3 px-4 py-3 rounded-xl bg-card/60 border border-border/50 backdrop-blur-md hover:border-primary/30 transition-colors"
            >
              <div className="w-9 h-9 rounded-lg bg-primary/12 border border-primary/25 flex items-center justify-center flex-shrink-0">
                <Icon className="w-4 h-4 text-primary" />
              </div>
              <div className="flex flex-col items-start min-w-0">
                <div className="text-2xl md:text-2xl font-heading font-bold text-primary leading-none">{s.value}</div>
                <div className="text-[16px] md:text-base text-foreground/85 mt-1 leading-tight">{s.label}</div>
              </div>
            </div>
          );
        })}
      </motion.div>
    </section>
  );
}