import React, { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Sparkles, Pencil, Check, X, Image as ImageIcon } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useInlineEdit } from "@/components/inline-edit/InlineEditContext";
import { renderRichText } from "@/lib/renderRichText";
import { getStyleConfig, DEFAULT_FIELD_STYLE } from "@/components/inline-edit/fieldStyles";
import StylePicker from "@/components/inline-edit/StylePicker";

/**
 * Inline-editable field bound to a specific CustomSection record + field name.
 * Resolves its visual style from section.style_overrides[field] (with fallback to defaults),
 * and (in edit mode) exposes a StylePicker so admins can change the look per-field.
 */
export function EditableField({ section, field, fallback = "", as: Tag = "span", extraClassName = "" }) {
  const { enabled } = useInlineEdit();
  const queryClient = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState("");
  const [saving, setSaving] = useState(false);
  const inputRef = useRef(null);

  const value = section?.[field] ?? "";
  const overrides = section?.style_overrides || {};
  const currentStyleKey = overrides[field] || DEFAULT_FIELD_STYLE[field] || "body";
  const isHidden = currentStyleKey === "hidden";
  const styleCfg = getStyleConfig(field, overrides);
  const multiline = styleCfg.isMultiline;
  const className = `${styleCfg.className} ${extraClassName}`.trim();

  useEffect(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select?.();
    }
  }, [editing]);

  const startEdit = (e) => {
    if (!enabled) return;
    e.preventDefault();
    e.stopPropagation();
    setVal(value);
    setEditing(true);
  };

  const save = async () => {
    if (val === value) return setEditing(false);
    setSaving(true);
    try {
      await base44.entities.CustomSection.update(section.id, { [field]: val });
      await queryClient.invalidateQueries({ queryKey: ["custom_sections"] });
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  const cancel = () => { setEditing(false); setVal(""); };

  const handleKeyDown = (e) => {
    if (e.key === "Escape") { e.preventDefault(); cancel(); }
    else if (e.key === "Enter" && (!multiline || e.ctrlKey || e.metaKey)) { e.preventDefault(); save(); }
  };

  const updateStyle = async (newKey) => {
    const nextOverrides = { ...overrides, [field]: newKey };
    await base44.entities.CustomSection.update(section.id, { style_overrides: nextOverrides });
    await queryClient.invalidateQueries({ queryKey: ["custom_sections"] });
  };

  if (!enabled) {
    if (isHidden) return null;
    return value ? <Tag className={className}>{multiline ? renderRichText(value) : value}</Tag> : null;
  }

  if (isHidden && !editing) {
    return (
      <Tag className="inline-flex items-center gap-2 px-2 py-1 rounded border border-dashed border-muted-foreground/40 bg-muted/30 text-xs text-muted-foreground opacity-70">
        <span>שדה מוסתר: {field}</span>
        <StylePicker field={field} currentKey={currentStyleKey} onSelect={updateStyle} />
      </Tag>
    );
  }

  if (!editing) {
    return (
      <Tag
        className={`${className} relative cursor-text outline outline-1 outline-transparent hover:outline-primary/60 hover:bg-primary/5 rounded transition-colors`}
        onClick={startEdit}
        title="לחץ לעריכה"
      >
        {value ? (multiline ? renderRichText(value) : value) : <span className="opacity-50">{fallback}</span>}
        <StylePicker field={field} currentKey={currentStyleKey} onSelect={updateStyle} />
        <Pencil className="inline-block w-3 h-3 mr-1 text-primary/70 align-baseline" />
      </Tag>
    );
  }

  return (
    <Tag className={`${className} relative ${multiline ? "block w-full" : "inline-block align-baseline"}`} style={multiline ? undefined : { minWidth: "4ch" }}>
      {multiline ? (
        <textarea
          ref={inputRef}
          value={val}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={handleKeyDown}
          dir="rtl"
          rows={Math.max(8, val.split("\n").length + 1)}
          className="block w-full min-w-full md:min-w-[600px] min-h-[240px] bg-background/95 border-2 border-primary rounded-lg p-3 text-current font-[inherit] leading-relaxed resize-y outline-none focus:ring-2 focus:ring-primary/40"
        />
      ) : (
        <input
          ref={inputRef}
          value={val}
          onChange={(e) => setVal(e.target.value)}
          onKeyDown={handleKeyDown}
          dir="rtl"
          className="w-full min-w-[180px] bg-background/95 border-2 border-primary rounded-md px-2 py-0.5 text-current font-[inherit] outline-none focus:ring-2 focus:ring-primary/40"
          style={{ fontSize: "inherit", fontWeight: "inherit", lineHeight: "inherit", color: "inherit" }}
        />
      )}
      <span className="inline-flex items-center gap-1 mr-2 align-middle">
        <button type="button" onClick={save} disabled={saving}
          className="inline-flex items-center justify-center w-6 h-6 rounded bg-primary text-primary-foreground hover:bg-primary/90 disabled:opacity-50">
          <Check className="w-3.5 h-3.5" />
        </button>
        <button type="button" onClick={cancel}
          className="inline-flex items-center justify-center w-6 h-6 rounded bg-secondary text-foreground hover:bg-secondary/80 border border-border">
          <X className="w-3.5 h-3.5" />
        </button>
      </span>
    </Tag>
  );
}

function ImageField({ section }) {
  const { enabled } = useInlineEdit();
  const queryClient = useQueryClient();
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef(null);

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      await base44.entities.CustomSection.update(section.id, { image_url: file_url });
      await queryClient.invalidateQueries({ queryKey: ["custom_sections"] });
    } finally {
      setUploading(false);
    }
  };

  if (!section.image_url && !enabled) return null;

  return (
    <div className="relative inline-block">
      {section.image_url ? (
        <img src={section.image_url} alt="" className="w-20 h-20 rounded-full object-cover border-2 border-primary/30" />
      ) : (
        <div className="w-20 h-20 rounded-full border-2 border-dashed border-primary/40 bg-secondary/40 flex items-center justify-center">
          <ImageIcon className="w-6 h-6 text-muted-foreground" />
        </div>
      )}
      {enabled && (
        <>
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={uploading}
            className="absolute -bottom-1 -left-1 w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg hover:bg-primary/90"
            title="העלה תמונה"
          >
            {uploading ? <span className="w-3 h-3 border-2 border-primary-foreground/40 border-t-primary-foreground rounded-full animate-spin" /> : <Pencil className="w-3 h-3" />}
          </button>
          <input ref={inputRef} type="file" accept="image/*" onChange={handleUpload} className="hidden" />
        </>
      )}
    </div>
  );
}

/**
 * Renders just the inner card (story body + customer info) — used by CustomerStoriesGroup
 * to render multiple stories sharing one outer header.
 */
export function CustomSectionCard({ section }) {
  const { enabled } = useInlineEdit();
  if (!section) return null;
  const isCustomerStory = section.section_type === "customer_story";

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: 0.1 }}
      className="rounded-2xl border border-border/50 bg-card/60 backdrop-blur-md md:p-10 p-6"
    >
      <EditableField as="div" section={section} field="body" fallback="ספר כאן את סיפור הלקוח..." />
    </motion.div>
  );
}

export default function CustomSectionRenderer({ section }) {
  const { enabled } = useInlineEdit();
  if (!section) return null;
  const isCustomerStory = section.section_type === "customer_story";

  return (
    <section className="relative py-16 md:py-20 px-4 overflow-hidden" dir="rtl">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="relative z-10 max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          {(section.badge || enabled) && (
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/10 mb-5">
              <Sparkles className="w-3.5 h-3.5 text-primary" />
              <EditableField section={section} field="badge" fallback="סיפור לקוח" />
            </div>
          )}

          <h2 className="mb-4">
            <EditableField section={section} field="heading" fallback="תנו לנו לספר לכם על..." />
            {(section.heading_highlight || enabled) && (
              <>
                {" "}
                <EditableField section={section} field="heading_highlight" fallback="לקוח שלנו" />
              </>
            )}
          </h2>

          {(section.subheading || enabled) && (
            <EditableField as="p" section={section} field="subheading" fallback="תת-כותרת..." extraClassName="mx-auto" />
          )}
        </motion.div>

        <CustomSectionCard section={section} />
      </div>
    </section>
  );
}