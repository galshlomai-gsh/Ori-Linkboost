import React from "react";
import { motion } from "framer-motion";
import { Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import EditableText from "@/components/inline-edit/EditableText";

/**
 * CTA1 — the first call-to-action block (previously embedded inside HeroSection).
 * Contains: short pitch lines, primary CTA button, and a small note below.
 * Content is stored under the "hero" section keys to preserve existing data.
 */
export default function CTA1Section({ onStartQuiz }) {
  return (
    <section id="cta1" className="relative px-4 py-16 md:py-24" dir="rtl">
      <div className="relative z-10 max-w-4xl mx-auto text-center">
        {/* USP — two stacked lines, each individually editable & styleable */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-4"
        >
          <EditableText
            section="hero"
            k="subtext"
            fallback="תן לנו לנהל עבורך את כל בניית הקישורים –"
            as="p"
            multiline
            styleable
            className="text-lg md:text-2xl text-foreground/90 max-w-3xl mx-auto leading-relaxed mb-2"
          />
          <EditableText
            section="hero"
            k="subtext2"
            fallback="ואתה תתמקד בקידום ובסקייל של הלקוחות שלך."
            as="p"
            multiline
            styleable
            className="text-lg md:text-2xl text-foreground/90 max-w-3xl mx-auto leading-relaxed"
          />
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.15 }}
          className="mb-10"
        >
          <EditableText
            section="hero"
            k="subtext3"
            fallback="קישורים איכותיים, תהליך מסודר, דוחות שקופים – בלי כאב ראש"
            as="p"
            multiline
            styleable
            className="text-base md:text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed"
          />
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-col items-center gap-3"
        >
          <Button
            onClick={onStartQuiz}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-heading font-semibold text-lg md:text-xl px-10 py-7 rounded-xl transition-all duration-300 hover:scale-[1.03]"
            style={{ animation: "ctaPulse 3s ease-in-out infinite" }}
          >
            <Zap className="w-5 h-5 ml-2 fill-primary-foreground" />
            <EditableText section="hero" k="cta_button" fallback="התחל ניתוח SEO חינם · 2 דקות" styleable />
          </Button>
          <EditableText
            as="p"
            section="hero"
            k="cta_note"
            fallback="ללא התחייבות. מותאם לסוכנויות SEO ופרילנסרים."
            styleable
            className="text-sm text-muted-foreground"
          />
        </motion.div>
      </div>
    </section>
  );
}