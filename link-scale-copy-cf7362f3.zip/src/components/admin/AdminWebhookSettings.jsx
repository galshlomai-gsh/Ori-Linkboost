import React, { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Webhook, Save, CheckCircle2, Send, Loader2 } from "lucide-react";
import AdminWebhookPreview from "./AdminWebhookPreview";

const CONFIG_KEY = "make_webhook_url";

export default function AdminWebhookSettings() {
  const queryClient = useQueryClient();
  const [url, setUrl] = useState("");
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState(null);
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState(null);

  const { data: configs = [], isLoading } = useQuery({
    queryKey: ["app_config", CONFIG_KEY],
    queryFn: () => base44.entities.AppConfiguration.filter({ key: CONFIG_KEY }),
  });

  const current = configs[0];

  useEffect(() => {
    if (current) setUrl(current.value || "");
  }, [current]);

  const save = async () => {
    setSaving(true);
    try {
      if (current) {
        await base44.entities.AppConfiguration.update(current.id, { value: url });
      } else {
        await base44.entities.AppConfiguration.create({
          key: CONFIG_KEY,
          value: url,
          description: "כתובת ה-Webhook של Make.com לשליחת לידים ותשובות השאלון",
        });
      }
      await queryClient.invalidateQueries({ queryKey: ["app_config", CONFIG_KEY] });
      setSavedAt(new Date());
    } finally {
      setSaving(false);
    }
  };

  const sendTest = async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const res = await base44.functions.invoke("sendTestLead", {});
      setTestResult({ ok: true, message: res.data?.message || "נשלח בהצלחה" });
    } catch (e) {
      setTestResult({ ok: false, message: e?.response?.data?.error || e.message });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="max-w-3xl space-y-6" dir="rtl">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center">
          <Webhook className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h2 className="font-heading text-xl font-bold">הגדרות Webhook (Make.com)</h2>
          <p className="text-sm text-muted-foreground">בעת שמירת ליד חדש, נשלחים כל הפרטים והתשובות לכתובת זו.</p>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 space-y-4">
        <div className="space-y-2">
          <Label htmlFor="webhook-url">כתובת ה-Webhook</Label>
          <Input
            id="webhook-url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://hook.eu1.make.com/..."
            dir="ltr"
            disabled={isLoading}
            className="font-mono text-sm"
          />
          <p className="text-xs text-muted-foreground">
            השאר ריק כדי לבטל את השליחה ל-Make.com.
          </p>
        </div>

        <div className="flex items-center gap-3 pt-2">
          <Button onClick={save} disabled={saving || isLoading} className="gap-2">
            <Save className="w-4 h-4" />
            {saving ? "שומר..." : "שמור"}
          </Button>
          {savedAt && (
            <span className="text-xs text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              נשמר בהצלחה
            </span>
          )}
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 space-y-3">
        <div>
          <h3 className="font-bold text-foreground">שליחת ליד טסט</h3>
          <p className="text-sm text-muted-foreground">יוצר ליד דמה עם שם, אימייל, טלפון ותשובות שאלון לדוגמה — ומפעיל את ה-Webhook אוטומטית.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button onClick={sendTest} disabled={testing} variant="secondary" className="gap-2">
            {testing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            {testing ? "שולח..." : "שלח ליד טסט"}
          </Button>
          {testResult && (
            <span className={`text-xs flex items-center gap-1 ${testResult.ok ? "text-emerald-400" : "text-red-400"}`}>
              {testResult.ok && <CheckCircle2 className="w-3.5 h-3.5" />}
              {testResult.message}
            </span>
          )}
        </div>
      </div>

      <div className="rounded-xl border border-border/60 bg-secondary/30 p-5 text-sm space-y-2">
        <h3 className="font-bold text-foreground">מה נשלח ל-Make?</h3>
        <ul className="list-disc pr-5 space-y-1 text-muted-foreground">
          <li>שם, אימייל, טלפון</li>
          <li>סיווג הליד (DIY / Managed)</li>
          <li>סטטוס ומקור</li>
          <li>כל השאלות והתשובות מהשאלון (כמערך ובנוסף כטקסט מסודר)</li>
          <li>תאריך יצירת הליד ו-ID</li>
        </ul>
      </div>

      <AdminWebhookPreview />
    </div>
  );
}