import React from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Eye, EyeOff } from "lucide-react";

const SECTIONS = [
  { key: "pain", label: "הזדהות עם הבעיה", description: "סקשן מיד אחרי ה-Hero, עם טקסט הזדהות" },
  { key: "objection", label: "אתה לא אמור לבנות קישורים בעצמך", description: "סקשן ההשוואות" },
  { key: "roi", label: "מחשבון עלות מול תועלת", description: "מחשבון ROI אינטראקטיבי" },
  { key: "testimonials", label: "המלצות לקוחות", description: "קרוסלת חוות הדעת" },
  { key: "benefits", label: "יתרונות / למה אנחנו", description: "רשת היתרונות" },
  { key: "cta", label: "קריאה לפעולה סופית", description: "ה-CTA הגדול בתחתית הדף" },
];

export default function AdminSectionVisibility() {
  const queryClient = useQueryClient();

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["section_visibility"],
    queryFn: () => base44.entities.SectionVisibility.list("", 100),
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["section_visibility"] });

  const toggleMut = useMutation({
    mutationFn: async ({ sectionKey, isVisible }) => {
      const existing = items.find((i) => i.section_key === sectionKey);
      if (existing) {
        return base44.entities.SectionVisibility.update(existing.id, { is_visible: isVisible });
      }
      return base44.entities.SectionVisibility.create({ section_key: sectionKey, is_visible: isVisible });
    },
    onSuccess: invalidate,
  });

  const getVisibility = (key) => {
    const rec = items.find((i) => i.section_key === key);
    return rec ? rec.is_visible !== false : true;
  };

  return (
    <div className="space-y-4" dir="rtl">
      <div>
        <h2 className="font-heading text-xl font-bold">תצוגת סקשנים</h2>
        <p className="text-sm text-muted-foreground">הצג או הסתר סקשנים שלמים באתר בלחיצה אחת</p>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-10">
          <div className="w-6 h-6 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-3">
          {SECTIONS.map((section) => {
            const visible = getVisibility(section.key);
            return (
              <div
                key={section.key}
                className="bg-card border border-border/60 rounded-xl p-4 flex items-center gap-4"
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${visible ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"}`}>
                  {visible ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-foreground">{section.label}</div>
                  <div className="text-xs text-muted-foreground">{section.description}</div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Label className="text-xs text-muted-foreground">
                    {visible ? "מוצג" : "מוסתר"}
                  </Label>
                  <Switch
                    checked={visible}
                    onCheckedChange={(v) => toggleMut.mutate({ sectionKey: section.key, isVisible: v })}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}