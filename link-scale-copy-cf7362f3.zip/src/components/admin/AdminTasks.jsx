import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Trash2,
  Pencil,
  Check,
  X,
  Circle,
  ArrowUpCircle,
  CheckCircle2,
  Calendar as CalendarIcon,
  ListTodo,
  Loader2,
} from "lucide-react";

const STATUS_META = {
  todo: { label: "לביצוע", icon: Circle, color: "text-muted-foreground" },
  in_progress: { label: "בתהליך", icon: ArrowUpCircle, color: "text-primary" },
  done: { label: "הושלם", icon: CheckCircle2, color: "text-emerald-400" },
};

const PRIORITY_META = {
  low: { label: "נמוכה", className: "bg-secondary text-muted-foreground border-border" },
  medium: { label: "בינונית", className: "bg-amber-500/15 text-amber-400 border-amber-500/30" },
  high: { label: "גבוהה", className: "bg-red-500/15 text-red-400 border-red-500/30" },
};

const EMPTY_TASK = {
  title: "",
  description: "",
  status: "todo",
  priority: "medium",
  due_date: "",
};

export default function AdminTasks() {
  const queryClient = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY_TASK);
  const [saving, setSaving] = useState(false);
  const [filterStatus, setFilterStatus] = useState("all");

  const { data: tasks = [], isLoading } = useQuery({
    queryKey: ["admin-tasks"],
    queryFn: () => base44.entities.Task.list("-created_date", 200),
  });

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["admin-tasks"] });

  const startCreate = () => {
    setEditing(null);
    setForm(EMPTY_TASK);
    setShowForm(true);
  };

  const startEdit = (task) => {
    setEditing(task);
    setForm({
      title: task.title || "",
      description: task.description || "",
      status: task.status || "todo",
      priority: task.priority || "medium",
      due_date: task.due_date || "",
    });
    setShowForm(true);
  };

  const cancelForm = () => {
    setShowForm(false);
    setEditing(null);
    setForm(EMPTY_TASK);
  };

  const submit = async () => {
    if (!form.title.trim()) return;
    setSaving(true);
    try {
      const payload = { ...form };
      if (!payload.due_date) delete payload.due_date;
      if (editing) {
        await base44.entities.Task.update(editing.id, payload);
      } else {
        await base44.entities.Task.create(payload);
      }
      await refresh();
      cancelForm();
    } finally {
      setSaving(false);
    }
  };

  const remove = async (task) => {
    if (!confirm(`למחוק את "${task.title}"?`)) return;
    await base44.entities.Task.delete(task.id);
    await refresh();
  };

  const changeStatus = async (task, status) => {
    await base44.entities.Task.update(task.id, { status });
    await refresh();
  };

  const filtered = tasks.filter((t) => filterStatus === "all" || t.status === filterStatus);
  const counts = {
    all: tasks.length,
    todo: tasks.filter((t) => t.status === "todo").length,
    in_progress: tasks.filter((t) => t.status === "in_progress").length,
    done: tasks.filter((t) => t.status === "done").length,
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/15 flex items-center justify-center">
            <ListTodo className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="font-heading text-xl font-bold">ניהול משימות</h2>
            <p className="text-sm text-muted-foreground">משימות פנימיות לצוות / לעצמך</p>
          </div>
        </div>
        <Button onClick={startCreate} className="gap-2">
          <Plus className="w-4 h-4" />
          משימה חדשה
        </Button>
      </div>

      {/* Filter chips */}
      <div className="flex items-center gap-2 flex-wrap">
        {[
          { key: "all", label: "הכל" },
          { key: "todo", label: STATUS_META.todo.label },
          { key: "in_progress", label: STATUS_META.in_progress.label },
          { key: "done", label: STATUS_META.done.label },
        ].map((f) => (
          <button
            key={f.key}
            onClick={() => setFilterStatus(f.key)}
            className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
              filterStatus === f.key
                ? "bg-primary text-primary-foreground border-primary"
                : "bg-secondary/40 text-muted-foreground border-border hover:text-foreground"
            }`}
          >
            {f.label}
            <span className="mr-1 opacity-70">({counts[f.key]})</span>
          </button>
        ))}
      </div>

      {/* Form */}
      {showForm && (
        <div className="rounded-xl border border-border bg-card p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold">{editing ? "עריכת משימה" : "משימה חדשה"}</h3>
            <button onClick={cancelForm} className="text-muted-foreground hover:text-foreground">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-2">
            <Label>כותרת</Label>
            <Input
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="מה צריך לעשות?"
            />
          </div>

          <div className="space-y-2">
            <Label>תיאור (אופציונלי)</Label>
            <Textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="פרטים נוספים..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>סטטוס</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="todo">{STATUS_META.todo.label}</SelectItem>
                  <SelectItem value="in_progress">{STATUS_META.in_progress.label}</SelectItem>
                  <SelectItem value="done">{STATUS_META.done.label}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>עדיפות</Label>
              <Select value={form.priority} onValueChange={(v) => setForm({ ...form, priority: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">{PRIORITY_META.low.label}</SelectItem>
                  <SelectItem value="medium">{PRIORITY_META.medium.label}</SelectItem>
                  <SelectItem value="high">{PRIORITY_META.high.label}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>תאריך יעד</Label>
              <Input
                type="date"
                value={form.due_date}
                onChange={(e) => setForm({ ...form, due_date: e.target.value })}
              />
            </div>
          </div>

          <div className="flex items-center gap-2 pt-2">
            <Button onClick={submit} disabled={saving || !form.title.trim()} className="gap-2">
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              {saving ? "שומר..." : editing ? "עדכן" : "צור משימה"}
            </Button>
            <Button onClick={cancelForm} variant="secondary">ביטול</Button>
          </div>
        </div>
      )}

      {/* List */}
      {isLoading ? (
        <div className="flex items-center gap-2 text-muted-foreground text-sm py-8">
          <Loader2 className="w-4 h-4 animate-spin" />
          טוען משימות...
        </div>
      ) : filtered.length === 0 ? (
        <div className="rounded-xl border border-dashed border-border bg-card/50 p-10 text-center">
          <ListTodo className="w-10 h-10 text-muted-foreground/40 mx-auto mb-3" />
          <p className="text-sm text-muted-foreground">אין משימות להצגה</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((task) => {
            const StatusIcon = STATUS_META[task.status]?.icon || Circle;
            const statusColor = STATUS_META[task.status]?.color || "text-muted-foreground";
            const priority = PRIORITY_META[task.priority] || PRIORITY_META.medium;
            return (
              <div
                key={task.id}
                className="rounded-xl border border-border bg-card p-4 flex items-start gap-3"
              >
                <Select value={task.status} onValueChange={(v) => changeStatus(task, v)}>
                  <SelectTrigger className="w-auto border-none bg-transparent p-0 h-auto hover:opacity-70 [&>svg]:hidden mt-1">
                    <StatusIcon className={`w-5 h-5 ${statusColor}`} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todo">{STATUS_META.todo.label}</SelectItem>
                    <SelectItem value="in_progress">{STATUS_META.in_progress.label}</SelectItem>
                    <SelectItem value="done">{STATUS_META.done.label}</SelectItem>
                  </SelectContent>
                </Select>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4
                      className={`font-semibold text-foreground ${
                        task.status === "done" ? "line-through text-muted-foreground" : ""
                      }`}
                    >
                      {task.title}
                    </h4>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full border ${priority.className}`}>
                      עדיפות {priority.label}
                    </span>
                    {task.due_date && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full border border-border bg-secondary/40 text-muted-foreground inline-flex items-center gap-1">
                        <CalendarIcon className="w-3 h-3" />
                        {task.due_date}
                      </span>
                    )}
                  </div>
                  {task.description && (
                    <p className="text-sm text-muted-foreground mt-1 whitespace-pre-line">
                      {task.description}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => startEdit(task)}
                    className="p-2 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors"
                    title="ערוך"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => remove(task)}
                    className="p-2 rounded-lg hover:bg-red-500/10 text-muted-foreground hover:text-red-400 transition-colors"
                    title="מחק"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}