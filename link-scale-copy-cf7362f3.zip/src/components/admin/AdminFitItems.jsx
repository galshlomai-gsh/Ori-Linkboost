import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Pencil, Check, X, Plus, Trash2, EyeOff, Eye, GripVertical } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

function FitItemRow({ item, onSave, onDelete, onToggle, dragHandleProps }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(item.text);

  const handleSave = () => {
    onSave(item.id, val);
    setEditing(false);
  };

  return (
    <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/40 border border-border/30 group">
      {!editing && (
        <span {...dragHandleProps} className="cursor-grab active:cursor-grabbing text-muted-foreground/50 hover:text-muted-foreground flex-shrink-0">
          <GripVertical className="w-4 h-4" />
        </span>
      )}
      {editing ? (
        <>
          <Input
            value={val}
            onChange={(e) => setVal(e.target.value)}
            className="flex-1 text-sm h-8"
            dir="rtl"
            autoFocus
            onKeyDown={(e) => e.key === "Enter" && handleSave()}
          />
          <Button size="icon" variant="ghost" className="h-7 w-7 text-primary" onClick={handleSave}>
            <Check className="w-3.5 h-3.5" />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7 text-muted-foreground" onClick={() => { setVal(item.text); setEditing(false); }}>
            <X className="w-3.5 h-3.5" />
          </Button>
        </>
      ) : (
        <>
          <span className={`flex-1 text-sm ${item.is_active === false ? "opacity-40 line-through" : ""}`} dir="rtl">{item.text}</span>
          <Button size="icon" variant="ghost" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => onToggle(item)}>
            {item.is_active === false ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => setEditing(true)}>
            <Pencil className="w-3.5 h-3.5" />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-destructive" onClick={() => onDelete(item.id)}>
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </>
      )}
    </div>
  );
}

function AddForm({ type, onAdd, onCancel }) {
  const [text, setText] = useState("");
  return (
    <div className="flex gap-2 p-3 rounded-lg border border-primary/20 bg-primary/5">
      <Input
        placeholder={type === "fit" ? "לדוגמה: אתה רוצה תהליך מסודר ושקוף" : "לדוגמה: אתה מחפש קישורים ב-50 ₪"}
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="flex-1 text-sm h-8"
        dir="rtl"
        autoFocus
        onKeyDown={(e) => e.key === "Enter" && text && onAdd(type, text)}
      />
      <Button size="sm" className="h-8" onClick={() => text && onAdd(type, text)} disabled={!text}>
        <Check className="w-3.5 h-3.5" />
      </Button>
      <Button size="sm" variant="ghost" className="h-8" onClick={onCancel}>
        <X className="w-3.5 h-3.5" />
      </Button>
    </div>
  );
}

function EditableColumnTitle({ value, icon, accentColor, onSave }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(value);

  React.useEffect(() => { setVal(value); }, [value]);

  const save = () => {
    if (val && val !== value) onSave(val);
    setEditing(false);
  };

  if (editing) {
    return (
      <div className="flex items-center gap-2 flex-1">
        <span className="text-base">{icon}</span>
        <Input
          value={val}
          onChange={(e) => setVal(e.target.value)}
          className="flex-1 text-sm h-8"
          dir="rtl"
          autoFocus
          onKeyDown={(e) => { if (e.key === "Enter") save(); if (e.key === "Escape") { setVal(value); setEditing(false); } }}
        />
        <Button size="icon" variant="ghost" className="h-7 w-7 text-primary" onClick={save}><Check className="w-3.5 h-3.5" /></Button>
        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { setVal(value); setEditing(false); }}><X className="w-3.5 h-3.5" /></Button>
      </div>
    );
  }

  return (
    <button onClick={() => setEditing(true)} className={`group flex items-center gap-2 font-semibold text-sm ${accentColor} hover:opacity-80 transition-opacity`}>
      <span>{icon}</span>
      <span>{value}</span>
      <Pencil className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
    </button>
  );
}

export default function AdminFitItems() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [addingTo, setAddingTo] = useState(null);

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["fit_items_all"],
    queryFn: () => base44.entities.FitItem.list("order_index", 200),
  });

  const { data: contentItems = [] } = useQuery({
    queryKey: ["landing_content", "fit"],
    queryFn: () => base44.entities.LandingContent.filter({ section: "fit" }, "order_index", 100),
  });

  const getContent = (key, fallback) => contentItems.find((c) => c.key === key)?.value || fallback;
  const getContentId = (key) => contentItems.find((c) => c.key === key)?.id;

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["fit_items_all"] });
    queryClient.invalidateQueries({ queryKey: ["fit_items"] });
  };

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.FitItem.update(id, data),
    onSuccess: () => { invalidate(); toast({ title: "נשמר!", duration: 2000 }); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.FitItem.delete(id),
    onSuccess: invalidate,
  });

  const createMutation = useMutation({
    mutationFn: ({ type, text }) => base44.entities.FitItem.create({ type, text, order_index: items.length, is_active: true }),
    onSuccess: () => { invalidate(); setAddingTo(null); toast({ title: "נוסף!", duration: 2000 }); },
  });

  const reorderMutation = useMutation({
    mutationFn: async (reordered) => {
      await Promise.all(
        reordered.map((it, idx) =>
          it.order_index !== idx ? base44.entities.FitItem.update(it.id, { order_index: idx }) : null
        )
      );
    },
    onSuccess: invalidate,
  });

  const handleDragEnd = (result, list) => {
    if (!result.destination) return;
    const reordered = Array.from(list);
    const [moved] = reordered.splice(result.source.index, 1);
    reordered.splice(result.destination.index, 0, moved);
    reorderMutation.mutate(reordered);
  };

  const saveTitleMutation = useMutation({
    mutationFn: async ({ key, value }) => {
      const existingId = getContentId(key);
      if (existingId) return base44.entities.LandingContent.update(existingId, { value });
      return base44.entities.LandingContent.create({ section: "fit", key, value, order_index: 0 });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["landing_content", "fit"] });
      queryClient.invalidateQueries({ queryKey: ["landing_content"] });
      toast({ title: "כותרת עודכנה!", duration: 2000 });
    },
  });

  const fitItems = items.filter((i) => i.type === "fit");
  const unfitItems = items.filter((i) => i.type === "unfit");

  if (isLoading) return <div className="text-center py-12 text-muted-foreground">טוען...</div>;

  const renderColumn = (type, titleKey, defaultTitle, icon, list, accentColor) => (
    <div className="rounded-2xl border border-border/40 bg-card overflow-hidden">
      <div className="flex items-center justify-between gap-2 px-4 py-3 border-b border-border/30 bg-secondary/30">
        <EditableColumnTitle
          value={getContent(titleKey, defaultTitle)}
          icon={icon}
          accentColor={accentColor}
          onSave={(value) => saveTitleMutation.mutate({ key: titleKey, value })}
        />
        <Button size="sm" variant="ghost" className="h-7 text-xs gap-1 flex-shrink-0" onClick={() => setAddingTo(type === addingTo ? null : type)}>
          <Plus className="w-3.5 h-3.5" /> הוסף
        </Button>
      </div>
      <div className="p-3 space-y-2">
        {list.length === 0 && addingTo !== type && (
          <p className="text-xs text-muted-foreground text-center py-2">אין פריטים עדיין</p>
        )}
        <DragDropContext onDragEnd={(r) => handleDragEnd(r, list)}>
          <Droppable droppableId={`droppable-${type}`}>
            {(provided) => (
              <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-2">
                {list.map((item, index) => (
                  <Draggable key={item.id} draggableId={item.id} index={index}>
                    {(prov, snapshot) => (
                      <div
                        ref={prov.innerRef}
                        {...prov.draggableProps}
                        className={snapshot.isDragging ? "opacity-90" : ""}
                      >
                        <FitItemRow
                          item={item}
                          dragHandleProps={prov.dragHandleProps}
                          onSave={(id, text) => updateMutation.mutate({ id, data: { text } })}
                          onDelete={(id) => deleteMutation.mutate(id)}
                          onToggle={(it) => updateMutation.mutate({ id: it.id, data: { is_active: !(it.is_active !== false) } })}
                        />
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
        {addingTo === type && (
          <AddForm
            type={type}
            onAdd={(t, text) => createMutation.mutate({ type: t, text })}
            onCancel={() => setAddingTo(null)}
          />
        )}
      </div>
    </div>
  );

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between mb-2">
        <h2 className="font-heading font-bold text-lg">סקשן "מתאים / לא מתאים"</h2>
        <p className="text-xs text-muted-foreground">ערוך את הכותרות והרשימות שמוצגות באתר</p>
      </div>

      <p className="text-xs text-muted-foreground">
        💡 לחץ על כותרת הטור כדי לערוך אותה · גרור פריטים מהאייקון השמאלי כדי לשנות סדר
      </p>

      <div className="grid md:grid-cols-2 gap-4">
        {renderColumn("fit", "fit_title", "מתאים לך אם...", "✅", fitItems, "text-primary")}
        {renderColumn("unfit", "unfit_title", "לא מתאים לך אם...", "❌", unfitItems, "text-destructive")}
      </div>
    </div>
  );
}