import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Button } from "@/components/ui/button";
import { Plus, GripVertical, Trash2, ArrowLeft, ChevronDown, ChevronUp, Eye, EyeOff } from "lucide-react";
import QuestionEditor from "./QuestionEditor";

export default function AdminQuestions() {
  const [editingId, setEditingId] = useState(null); // which question is expanded for editing
  const [addingNew, setAddingNew] = useState(false);
  const queryClient = useQueryClient();

  const { data: questions = [], isLoading } = useQuery({
    queryKey: ["admin-questions"],
    queryFn: () => base44.entities.Question.list("order_index"),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Question.update(id, data),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["admin-questions"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Question.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-questions"] });
      if (editingId) setEditingId(null);
    },
  });

  const handleDragEnd = (result) => {
    if (!result.destination) return;
    const items = Array.from(questions);
    const [reordered] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reordered);
    items.forEach((item, i) => {
      if (item.order_index !== i) {
        updateMutation.mutate({ id: item.id, data: { order_index: i } });
      }
    });
  };

  const getTypeLabel = (type) => {
    if (type === "buttons") return "בחירה יחידה";
    if (type === "multiple") return "בחירה מרובה";
    return "טקסט חופשי";
  };

  const getTypeColor = (type) => {
    if (type === "buttons") return "bg-primary/10 text-primary border-primary/20";
    if (type === "multiple") return "bg-accent/10 text-accent border-accent/20";
    return "bg-muted text-muted-foreground border-border";
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-20">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div dir="rtl" className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading text-xl font-bold">עריכת שלבי השאלון</h2>
          <p className="text-sm text-muted-foreground mt-1">
            {questions.length} שאלות · גרור לשינוי סדר · לחץ על שאלה לעריכה
          </p>
        </div>
        <Button
          onClick={() => { setAddingNew(true); setEditingId(null); }}
          className="bg-primary hover:bg-primary/90 text-primary-foreground font-medium"
        >
          <Plus className="w-4 h-4 ml-2" />
          שאלה חדשה
        </Button>
      </div>

      {/* Flow legend */}
      <div className="flex items-center gap-4 text-xs text-muted-foreground bg-muted/30 rounded-lg p-3 border border-border/30">
        <span className="font-medium text-foreground/70">לוגיקת מעבר:</span>
        <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-primary inline-block" /> תשובה → שאלה ספציפית</span>
        <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-muted-foreground inline-block" /> ברירת מחדל → שאלה הבאה</span>
        <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-accent inline-block" /> מסווג → DIY / Managed</span>
      </div>

      {/* Questions list */}
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="questions">
          {(provided) => (
            <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-3">
              {questions.map((q, i) => (
                <Draggable key={q.id} draggableId={q.id} index={i}>
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className={`rounded-xl border transition-all duration-200 overflow-hidden ${
                        snapshot.isDragging
                          ? "border-primary/40 shadow-lg shadow-primary/10 bg-card"
                          : editingId === q.id
                          ? "border-primary/50 bg-card"
                          : "border-border/50 bg-card hover:border-border"
                      }`}
                    >
                      {/* Question header row */}
                      <div
                        className="flex items-center gap-3 p-4 cursor-pointer"
                        onClick={() => setEditingId(editingId === q.id ? null : q.id)}
                      >
                        {/* Drag handle */}
                        <div
                          {...provided.dragHandleProps}
                          onClick={(e) => e.stopPropagation()}
                          className="cursor-grab active:cursor-grabbing p-1 rounded hover:bg-secondary transition-colors"
                        >
                          <GripVertical className="w-4 h-4 text-muted-foreground" />
                        </div>

                        {/* Step number */}
                        <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                          editingId === q.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
                        }`}>
                          {i + 1}
                        </div>

                        {/* Question info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`text-xs px-2 py-0.5 rounded-full border ${getTypeColor(q.type)}`}>
                              {getTypeLabel(q.type)}
                            </span>
                            {q.is_final && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-accent/10 text-accent border border-accent/20">
                                🎯 שאלת סיווג
                              </span>
                            )}
                            {!q.is_active && (
                              <span className="text-xs px-2 py-0.5 rounded-full bg-destructive/10 text-destructive border border-destructive/20">
                                מושבת
                              </span>
                            )}
                          </div>
                          <p className="font-medium text-sm mt-1 truncate">{q.title}</p>
                          {q.options?.length > 0 && (
                            <div className="flex items-center gap-1.5 mt-1.5 flex-wrap">
                              {q.options.slice(0, 4).map((opt, oi) => (
                                <span key={oi} className="text-xs text-muted-foreground bg-secondary/50 px-1.5 py-0.5 rounded flex items-center gap-1">
                                  {opt.icon && <span>{opt.icon}</span>}
                                  {opt.label}
                                  {opt.leads_to && (
                                    <ArrowLeft className="w-2.5 h-2.5 text-primary" />
                                  )}
                                  {opt.classification && (
                                    <span className={`text-xs font-bold ${opt.classification === "diy" ? "text-accent" : "text-primary"}`}>
                                      [{opt.classification.toUpperCase()}]
                                    </span>
                                  )}
                                </span>
                              ))}
                              {q.options.length > 4 && (
                                <span className="text-xs text-muted-foreground">+{q.options.length - 4}</span>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              updateMutation.mutate({ id: q.id, data: { is_active: q.is_active === false ? true : false } });
                            }}
                            className="h-8 w-8 text-muted-foreground hover:text-primary"
                            title={q.is_active === false ? "הצג שאלה" : "הסתר שאלה"}
                          >
                            {q.is_active === false ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => { e.stopPropagation(); deleteMutation.mutate(q.id); }}
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                          <div className="w-8 h-8 flex items-center justify-center text-muted-foreground">
                            {editingId === q.id ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </div>
                        </div>
                      </div>

                      {/* Inline editor */}
                      {editingId === q.id && (
                        <div className="border-t border-border/50 bg-background/50 p-5">
                          <QuestionEditor
                            question={q}
                            questions={questions}
                            onClose={() => setEditingId(null)}
                            onSaved={() => setEditingId(null)}
                          />
                        </div>
                      )}
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      {/* New question form */}
      {addingNew && (
        <div className="rounded-xl border border-primary/30 bg-card overflow-hidden">
          <div className="flex items-center gap-3 px-4 py-3 border-b border-border/50 bg-primary/5">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center text-xs font-bold text-primary-foreground">
              {questions.length + 1}
            </div>
            <span className="font-medium text-sm">שאלה חדשה</span>
          </div>
          <div className="p-5">
            <QuestionEditor
              question={null}
              questions={questions}
              onClose={() => setAddingNew(false)}
              onSaved={() => setAddingNew(false)}
            />
          </div>
        </div>
      )}

      {/* Add button at bottom */}
      {!addingNew && (
        <button
          onClick={() => { setAddingNew(true); setEditingId(null); }}
          className="w-full py-3 rounded-xl border border-dashed border-border/50 text-sm text-muted-foreground hover:border-primary/40 hover:text-primary transition-all duration-200 flex items-center justify-center gap-2"
        >
          <Plus className="w-4 h-4" />
          הוסף שאלה חדשה
        </button>
      )}
    </div>
  );
}