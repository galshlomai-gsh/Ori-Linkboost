import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Pencil, Check, X, Plus, Trash2, GripVertical, Copy, Bold, Palette } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/components/ui/use-toast";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

const SECTION_LABELS = {
  hero: "🚀 Hero – ראש הדף",
  pain: "😣 הזדהות עם הבעיה",
  fit: "🎯 מתאים / לא מתאים – כותרות",
  benefits: "✅ יתרונות",
  testimonials: "💬 המלצות",
  cta: "🎯 CTA – קריאה לפעולה",
  footer: "🔗 Footer",
};

const KEY_LABELS = {
  badge_text: "תווית עליונה",
  headline_line1: "כותרת – שורה 1",
  headline_line2: "כותרת – שורה 2 (צבעונית)",
  subtext: "טקסט משני",
  subtext2: "טקסט משני 2",
  cta_button: "כפתור CTA",
  cta_note: "הערת CTA",
  stats_links: "סטטיסטיקה – קישורים",
  stats_agencies: "סטטיסטיקה – סוכנויות",
  stats_sites: "סטטיסטיקה – אתרים",
  stats_retention: "סטטיסטיקה – שימור",
  section_label: "תווית סקשן",
  heading: "כותרת ראשית",
  subheading: "תת-כותרת",
  headline_line1_normal: "כותרת – חלק רגיל",
  headline_line1_colored: "כותרת – חלק צבעוני",
  body: "גוף טקסט",
  button: "כפתור",
  note: "הערה",
  copyright: "זכויות יוצרים",
  winning_sentence: "משפט מנצח (מעל ה-CTA)",
  fit_title: "כותרת – מתאים",
  unfit_title: "כותרת – לא מתאים",
  heading_highlight: "כותרת – חלק צבעוני",
  pain_text: "טקסט הזדהות / איתור הבעיה",
  sub_body: "טקסט משני",
  badge: "תווית עליונה",
  body_2: "גוף טקסט – פסקה 2",
  body_3: "גוף טקסט – פסקה 3",
  body_4: "גוף טקסט – פסקה 4",
  body_5: "גוף טקסט – פסקה 5",
};

const STYLE_OPTIONS = [
  {
    id: "heading",
    label: "כותרת ראשית",
    keyPrefix: "heading",
    preview: <div className="font-heading text-2xl font-extrabold text-foreground leading-tight">אתה מכיר את ההרגשה הזו?</div>,
  },
  {
    id: "body",
    label: "גוף טקסט",
    keyPrefix: "body",
    preview: <div className="text-base text-foreground/90 leading-relaxed">כל חודש מתחילים מהתחלה: מחפשים אתרים, מתמקחים על מחירים...</div>,
  },
  {
    id: "sub_body",
    label: "טקסט משני",
    keyPrefix: "sub_body",
    preview: <div className="text-sm text-muted-foreground leading-relaxed">אז מה אם נגיד לכם, שיש מקדמי אתרים שכבר אין להם את המחשבות האלה?</div>,
  },
  {
    id: "badge",
    label: "תווית עליונה",
    keyPrefix: "badge",
    preview: (
      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-destructive/30 bg-destructive/10">
        <span className="w-1.5 h-1.5 rounded-full bg-destructive" />
        <span className="text-xs text-destructive font-medium">מוכר לך?</span>
      </div>
    ),
  },
  {
    id: "note",
    label: "הערה קטנה",
    keyPrefix: "note",
    preview: <div className="text-xs text-muted-foreground">2 דקות · ללא התחייבות · מותאם לסוכנויות SEO</div>,
  },
];

// Detect which style a row currently uses, based on its key prefix.
function detectStyleId(key) {
  if (!key) return null;
  // Sort prefixes by length DESC so "sub_body" matches before "body"
  const sorted = [...STYLE_OPTIONS].sort((a, b) => b.keyPrefix.length - a.keyPrefix.length);
  const found = sorted.find((s) => key === s.keyPrefix || key.startsWith(s.keyPrefix + "_"));
  return found ? found.id : null;
}

// Build a new unique key for a target style, reusing the same suffix when possible.
function buildKeyForStyle(prefix, existingKeys) {
  const set = new Set(existingKeys);
  if (!set.has(prefix)) return prefix;
  let n = 2;
  while (set.has(`${prefix}_${n}`)) n++;
  return `${prefix}_${n}`;
}

function EditableRow({ item, onSave, onDelete, onDuplicate, onChangeStyle, sectionKeys, dragHandleProps, isDragging }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(item.value);
  const textareaRef = React.useRef(null);

  const handleSave = () => {
    onSave(item.id, val);
    setEditing(false);
  };

  const wrapBold = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    const selected = val.substring(start, end) || "טקסט מודגש";
    const newVal = val.substring(0, start) + `**${selected}**` + val.substring(end);
    setVal(newVal);
    setTimeout(() => {
      ta.focus();
      ta.setSelectionRange(start + 2, start + 2 + selected.length);
    }, 0);
  };

  return (
    <div className={`flex items-start gap-3 p-3 rounded-lg bg-secondary/40 border border-border/30 group ${isDragging ? "ring-2 ring-primary/50 shadow-xl bg-secondary/80" : ""}`}>
      <button
        type="button"
        {...dragHandleProps}
        className="text-muted-foreground hover:text-primary cursor-grab active:cursor-grabbing flex-shrink-0 touch-none p-1 -m-1 mt-1"
        title="גרור לסידור"
      >
        <GripVertical className="w-4 h-4" />
      </button>
      <span className="text-xs text-muted-foreground w-36 flex-shrink-0 truncate mt-2" title={item.key}>
        {KEY_LABELS[item.key] || item.key}
      </span>
      {editing ? (
        <div className="flex-1 flex flex-col gap-2">
          <div className="flex items-center gap-2">
            <Button type="button" size="icon" variant="ghost" className="h-7 w-7" onClick={wrapBold} title="הדגשה (**טקסט**)">
              <Bold className="w-3.5 h-3.5" />
            </Button>
            <span className="text-[10px] text-muted-foreground">סמן טקסט ולחץ B להדגשה • Enter = שורה חדשה • Ctrl+Enter = שמירה</span>
          </div>
          <Textarea
            ref={textareaRef}
            value={val}
            onChange={(e) => setVal(e.target.value)}
            className="flex-1 text-sm min-h-[100px]"
            dir="rtl"
            autoFocus
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
                e.preventDefault();
                handleSave();
              }
            }}
          />
          <div className="flex items-center gap-2 justify-end">
            <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => { setVal(item.value); setEditing(false); }}>
              <X className="w-3.5 h-3.5 ml-1" /> ביטול
            </Button>
            <Button size="sm" className="h-7 text-xs" onClick={handleSave}>
              <Check className="w-3.5 h-3.5 ml-1" /> שמור
            </Button>
          </div>
        </div>
      ) : (
        <>
          <button
            type="button"
            onClick={() => setEditing(true)}
            className="flex-1 text-sm text-right hover:bg-secondary/60 rounded px-2 py-1 -mx-1 transition-colors cursor-text whitespace-pre-wrap break-words leading-relaxed"
            dir="rtl"
            title="לחץ לעריכה"
          >
            {item.value}
          </button>
          <Button size="icon" variant="ghost" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => setEditing(true)}>
            <Pencil className="w-3.5 h-3.5" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="icon" variant="ghost" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity" title="שנה סטייל">
                <Palette className="w-3.5 h-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-72">
              <DropdownMenuLabel className="text-xs">בחר סטייל לשורה</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {STYLE_OPTIONS.map((opt) => {
                const currentStyle = detectStyleId(item.key);
                return (
                  <DropdownMenuItem
                    key={opt.id}
                    onClick={() => currentStyle !== opt.id && onChangeStyle(item, opt.id)}
                    className="flex-col items-stretch gap-2 py-2 cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-semibold">{opt.label}</span>
                      {currentStyle === opt.id && <Check className="w-3.5 h-3.5 text-primary" />}
                    </div>
                    <div className="bg-secondary/50 rounded p-2 min-h-[36px] flex items-center" dir="rtl">
                      {opt.preview}
                    </div>
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>
          <Button size="icon" variant="ghost" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => onDuplicate(item)} title="שכפל שורה">
            <Copy className="w-3.5 h-3.5" />
          </Button>
          <Button size="icon" variant="ghost" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-destructive" onClick={() => onDelete(item.id)}>
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </>
      )}
    </div>
  );
}

function AddRowForm({ section, sectionItems, onAdd, onCancel }) {
  const [styleId, setStyleId] = useState("body");
  const [value, setValue] = useState("");

  const handleSubmit = () => {
    if (!value.trim()) return;
    const style = STYLE_OPTIONS.find((s) => s.id === styleId);
    const prefix = style.keyPrefix;
    // Build unique key: prefix, prefix_2, prefix_3, ...
    const existing = new Set(sectionItems.map((it) => it.key));
    let newKey = prefix;
    let n = 2;
    while (existing.has(newKey)) {
      newKey = `${prefix}_${n}`;
      n++;
    }
    onAdd(section, newKey, value);
  };

  return (
    <div className="p-4 rounded-lg border border-primary/20 bg-primary/5 space-y-3">
      <div>
        <div className="text-xs font-semibold mb-2 text-muted-foreground">בחר סטייל:</div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {STYLE_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setStyleId(opt.id)}
              className={`text-right p-3 rounded-lg border transition-all ${
                styleId === opt.id
                  ? "border-primary bg-primary/10 ring-1 ring-primary/40"
                  : "border-border/40 bg-secondary/30 hover:border-border"
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-semibold">{opt.label}</span>
                {styleId === opt.id && <Check className="w-3.5 h-3.5 text-primary" />}
              </div>
              <div className="bg-background/50 rounded p-2 min-h-[44px] flex items-center" dir="rtl">
                {opt.preview}
              </div>
            </button>
          ))}
        </div>
      </div>

      <Textarea
        placeholder="כתוב את התוכן כאן..."
        value={value}
        onChange={(e) => setValue(e.target.value)}
        className="text-sm min-h-[80px]"
        dir="rtl"
      />

      <div className="flex items-center gap-2 justify-end">
        <Button size="sm" variant="ghost" className="h-8" onClick={onCancel}>
          <X className="w-3.5 h-3.5 ml-1" /> ביטול
        </Button>
        <Button size="sm" className="h-8" onClick={handleSubmit} disabled={!value.trim()}>
          <Check className="w-3.5 h-3.5 ml-1" /> הוסף שדה
        </Button>
      </div>
    </div>
  );
}

export default function AdminLandingContent() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [addingTo, setAddingTo] = useState(null);

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["landing_content"],
    queryFn: () => base44.entities.LandingContent.list("order_index", 200),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, value }) => base44.entities.LandingContent.update(id, { value }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["landing_content"] }); toast({ title: "נשמר!", duration: 2000 }); },
  });

  const reorderMutation = useMutation({
    mutationFn: ({ id, order_index }) => base44.entities.LandingContent.update(id, { order_index }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["landing_content"] }),
  });

  const handleDragEnd = async (result, sectionItems) => {
    if (!result.destination || result.destination.index === result.source.index) return;
    const newOrder = [...sectionItems];
    const [moved] = newOrder.splice(result.source.index, 1);
    newOrder.splice(result.destination.index, 0, moved);
    await Promise.all(
      newOrder
        .map((it, i) => (it.order_index === i ? null : reorderMutation.mutateAsync({ id: it.id, order_index: i })))
        .filter(Boolean)
    );
  };

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.LandingContent.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["landing_content"] }),
  });

  const createMutation = useMutation({
    mutationFn: ({ section, key, value, order_index }) =>
      base44.entities.LandingContent.create({ section, key, value, order_index }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["landing_content"] }); setAddingTo(null); toast({ title: "נוסף!", duration: 2000 }); },
  });

  const changeStyle = async (item, newStyleId, sectionItems) => {
    const style = STYLE_OPTIONS.find((s) => s.id === newStyleId);
    if (!style) return;
    const existingKeys = sectionItems.filter((it) => it.id !== item.id).map((it) => it.key);
    const newKey = buildKeyForStyle(style.keyPrefix, existingKeys);
    await base44.entities.LandingContent.update(item.id, { key: newKey });
    queryClient.invalidateQueries({ queryKey: ["landing_content"] });
    toast({ title: "הסטייל עודכן!", duration: 2000 });
  };

  const duplicateRow = async (item, sectionItems) => {
    const idx = sectionItems.findIndex((it) => it.id === item.id);
    // Build new key — append _copy / _copy2 / ... until unique
    const existingKeys = new Set(sectionItems.map((it) => it.key));
    let newKey = `${item.key}_copy`;
    let n = 2;
    while (existingKeys.has(newKey)) {
      newKey = `${item.key}_copy${n}`;
      n++;
    }
    // Shift items after current one by +1 to make room
    const after = sectionItems.slice(idx + 1);
    await Promise.all(
      after.map((it, i) =>
        reorderMutation.mutateAsync({ id: it.id, order_index: idx + 2 + i })
      )
    );
    await base44.entities.LandingContent.create({
      section: item.section,
      key: newKey,
      value: item.value,
      order_index: idx + 1,
    });
    queryClient.invalidateQueries({ queryKey: ["landing_content"] });
    toast({ title: "השורה שוכפלה!", duration: 2000 });
  };

  const grouped = items.reduce((acc, item) => {
    if (!acc[item.section]) acc[item.section] = [];
    acc[item.section].push(item);
    return acc;
  }, {});

  if (isLoading) return <div className="text-center py-12 text-muted-foreground">טוען...</div>;

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between mb-2">
        <h2 className="font-heading font-bold text-lg">תוכן עמוד הנחיתה</h2>
        <p className="text-xs text-muted-foreground">גרור את הידית כדי לסדר • לחץ על טקסט כדי לערוך</p>
      </div>

      {Object.entries(SECTION_LABELS).map(([section, label]) => {
        const sectionItems = grouped[section] || [];
        return (
          <div key={section} className="rounded-2xl border border-border/40 bg-card overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-border/30 bg-secondary/30">
              <span className="font-semibold text-sm">{label}</span>
              <Button size="sm" variant="ghost" className="h-7 text-xs gap-1" onClick={() => setAddingTo(section === addingTo ? null : section)}>
                <Plus className="w-3.5 h-3.5" /> הוסף שדה
              </Button>
            </div>
            <div className="p-3 space-y-2">
              {sectionItems.length === 0 && addingTo !== section && (
                <p className="text-xs text-muted-foreground text-center py-2">אין שדות עדיין</p>
              )}
              <DragDropContext onDragEnd={(result) => handleDragEnd(result, sectionItems)}>
                <Droppable droppableId={`section-${section}`}>
                  {(provided) => (
                    <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-2">
                      {sectionItems.map((item, idx) => (
                        <Draggable key={item.id} draggableId={item.id} index={idx}>
                          {(prov, snapshot) => (
                            <div ref={prov.innerRef} {...prov.draggableProps}>
                              <EditableRow
                                item={item}
                                onSave={(id, value) => updateMutation.mutate({ id, value })}
                                onDelete={(id) => deleteMutation.mutate(id)}
                                onDuplicate={(it) => duplicateRow(it, sectionItems)}
                                onChangeStyle={(it, newStyleId) => changeStyle(it, newStyleId, sectionItems)}
                                dragHandleProps={prov.dragHandleProps}
                                isDragging={snapshot.isDragging}
                              />
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </div>
                  )}
                </Droppable>
              </DragDropContext>
              {addingTo === section && (
                <AddRowForm
                  section={section}
                  sectionItems={sectionItems}
                  onAdd={(s, k, v) => {
                    const maxOrder = sectionItems.reduce((m, it) => Math.max(m, it.order_index ?? 0), -1);
                    createMutation.mutate({ section: s, key: k, value: v, order_index: maxOrder + 1 });
                  }}
                  onCancel={() => setAddingTo(null)}
                />
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}