import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pencil, Check, X, Plus, Trash2, Eye, EyeOff, Link2, Users, Globe2, Shield, TrendingUp, Award, Calendar, Database, Zap, CheckCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";

const ICON_OPTIONS = [
  { name: "Link2", Icon: Link2 },
  { name: "Users", Icon: Users },
  { name: "Globe2", Icon: Globe2 },
  { name: "Shield", Icon: Shield },
  { name: "TrendingUp", Icon: TrendingUp },
  { name: "Award", Icon: Award },
  { name: "Calendar", Icon: Calendar },
  { name: "Database", Icon: Database },
  { name: "Zap", Icon: Zap },
  { name: "CheckCircle", Icon: CheckCircle },
];

const ICON_MAP = Object.fromEntries(ICON_OPTIONS.map((o) => [o.name, o.Icon]));

function StatRow({ stat, onSave, onDelete, onToggle }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(stat.value);
  const [label, setLabel] = useState(stat.label);
  const [iconName, setIconName] = useState(stat.icon_name || "Link2");

  const Icon = ICON_MAP[stat.icon_name] || Link2;

  const save = () => {
    onSave(stat.id, { value, label, icon_name: iconName });
    setEditing(false);
  };

  if (editing) {
    return (
      <div className="flex flex-col md:flex-row gap-2 p-3 rounded-lg bg-secondary/40 border border-primary/30">
        <Input value={value} onChange={(e) => setValue(e.target.value)} className="w-full md:w-32 text-sm h-8" placeholder="+1000" dir="rtl" />
        <Input value={label} onChange={(e) => setLabel(e.target.value)} className="flex-1 text-sm h-8" placeholder="תיאור" dir="rtl" />
        <Select value={iconName} onValueChange={setIconName}>
          <SelectTrigger className="w-32 h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>
            {ICON_OPTIONS.map(({ name, Icon: I }) => (
              <SelectItem key={name} value={name}>
                <span className="flex items-center gap-2"><I className="w-3.5 h-3.5" /> {name}</span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex gap-1">
          <Button size="icon" variant="ghost" className="h-7 w-7 text-primary" onClick={save}><Check className="w-3.5 h-3.5" /></Button>
          <Button size="icon" variant="ghost" className="h-7 w-7 text-muted-foreground" onClick={() => setEditing(false)}><X className="w-3.5 h-3.5" /></Button>
        </div>
      </div>
    );
  }

  return (
    <div className={`flex items-center gap-3 p-3 rounded-lg bg-secondary/40 border border-border/30 group ${stat.is_active === false ? "opacity-50" : ""}`}>
      <div className="w-9 h-9 rounded-lg bg-primary/10 border border-primary/25 flex items-center justify-center flex-shrink-0">
        <Icon className="w-4 h-4 text-primary" />
      </div>
      <div className="font-heading font-bold text-primary text-lg w-24 flex-shrink-0">{stat.value}</div>
      <div className="flex-1 text-sm text-muted-foreground truncate" dir="rtl">{stat.label}</div>
      <Button size="icon" variant="ghost" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => onToggle(stat)}>
        {stat.is_active === false ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
      </Button>
      <Button size="icon" variant="ghost" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => setEditing(true)}><Pencil className="w-3.5 h-3.5" /></Button>
      <Button size="icon" variant="ghost" className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-destructive" onClick={() => onDelete(stat.id)}><Trash2 className="w-3.5 h-3.5" /></Button>
    </div>
  );
}

function AddStatForm({ onAdd, onCancel, defaultOrder }) {
  const [value, setValue] = useState("");
  const [label, setLabel] = useState("");
  const [iconName, setIconName] = useState("Link2");

  return (
    <div className="flex flex-col md:flex-row gap-2 p-3 rounded-lg border border-primary/20 bg-primary/5">
      <Input value={value} onChange={(e) => setValue(e.target.value)} className="w-full md:w-32 text-sm h-8" placeholder="+1000" autoFocus dir="rtl" />
      <Input value={label} onChange={(e) => setLabel(e.target.value)} className="flex-1 text-sm h-8" placeholder="לדוגמה: מאגר אתרים" dir="rtl" />
      <Select value={iconName} onValueChange={setIconName}>
        <SelectTrigger className="w-32 h-8 text-xs"><SelectValue /></SelectTrigger>
        <SelectContent>
          {ICON_OPTIONS.map(({ name, Icon: I }) => (
            <SelectItem key={name} value={name}>
              <span className="flex items-center gap-2"><I className="w-3.5 h-3.5" /> {name}</span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <div className="flex gap-1">
        <Button size="sm" className="h-8" disabled={!value || !label} onClick={() => onAdd({ value, label, icon_name: iconName, order_index: defaultOrder, is_active: true })}>
          <Check className="w-3.5 h-3.5" />
        </Button>
        <Button size="sm" variant="ghost" className="h-8" onClick={onCancel}><X className="w-3.5 h-3.5" /></Button>
      </div>
    </div>
  );
}

export default function AdminStats() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [adding, setAdding] = useState(false);

  const { data: stats = [], isLoading } = useQuery({
    queryKey: ["stats_all"],
    queryFn: () => base44.entities.Stat.list("order_index", 100),
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["stats_all"] });
    queryClient.invalidateQueries({ queryKey: ["stats_public"] });
  };

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Stat.update(id, data),
    onSuccess: () => { invalidate(); toast({ title: "נשמר!", duration: 2000 }); },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Stat.delete(id),
    onSuccess: invalidate,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Stat.create(data),
    onSuccess: () => { invalidate(); setAdding(false); toast({ title: "נוסף!", duration: 2000 }); },
  });

  if (isLoading) return <div className="text-center py-12 text-muted-foreground">טוען...</div>;

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex items-center justify-between mb-2">
        <h2 className="font-heading font-bold text-lg">סטטיסטיקות ה-Hero</h2>
        <Button size="sm" variant="outline" className="h-8 gap-1" onClick={() => setAdding(!adding)}>
          <Plus className="w-3.5 h-3.5" /> הוסף ריבוע
        </Button>
      </div>
      <p className="text-xs text-muted-foreground">הריבועים שמופיעים מתחת ל-CTA בראש הדף. ניתן להוסיף עוד ריבועים – הם יסתדרו אוטומטית.</p>

      <div className="space-y-2">
        {adding && (
          <AddStatForm
            defaultOrder={stats.length}
            onAdd={(data) => createMutation.mutate(data)}
            onCancel={() => setAdding(false)}
          />
        )}
        {stats.map((s) => (
          <StatRow
            key={s.id}
            stat={s}
            onSave={(id, data) => updateMutation.mutate({ id, data })}
            onDelete={(id) => deleteMutation.mutate(id)}
            onToggle={(st) => updateMutation.mutate({ id: st.id, data: { is_active: !(st.is_active !== false) } })}
          />
        ))}
        {stats.length === 0 && !adding && (
          <p className="text-sm text-muted-foreground text-center py-8">אין סטטיסטיקות עדיין. לחץ "הוסף ריבוע" כדי להתחיל.</p>
        )}
      </div>
    </div>
  );
}