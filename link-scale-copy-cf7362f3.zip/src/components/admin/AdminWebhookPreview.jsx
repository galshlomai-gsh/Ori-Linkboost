import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { ListChecks, UserSquare2, Loader2 } from "lucide-react";

export default function AdminWebhookPreview() {
  const { data: questions = [], isLoading } = useQuery({
    queryKey: ["admin-quiz-questions-preview"],
    queryFn: () => base44.entities.Question.filter({ is_active: true }, "order_index", 100),
  });

  return (
    <div className="space-y-6" dir="rtl">
      {/* Questions list */}
      <div className="rounded-xl border border-border bg-card p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center">
            <ListChecks className="w-4.5 h-4.5 text-primary" />
          </div>
          <div>
            <h3 className="font-bold text-foreground">שאלות השאלון</h3>
            <p className="text-xs text-muted-foreground">הסדר והתשובות שעלולים להישלח ל-Make</p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center gap-2 text-muted-foreground text-sm py-4">
            <Loader2 className="w-4 h-4 animate-spin" />
            טוען שאלות...
          </div>
        ) : questions.length === 0 ? (
          <p className="text-sm text-muted-foreground">אין שאלות פעילות</p>
        ) : (
          <ol className="space-y-3">
            {questions.map((q, idx) => (
              <li key={q.id} className="rounded-lg border border-border/60 bg-secondary/30 p-4">
                <div className="flex items-start gap-3">
                  <div className="w-7 h-7 rounded-full bg-primary/20 text-primary text-xs font-bold flex items-center justify-center flex-shrink-0">
                    {idx + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="font-semibold text-sm text-foreground">{q.title}</h4>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-muted text-muted-foreground border border-border">
                        {q.type === "buttons" ? "כפתורים" : q.type === "multiple" ? "בחירה מרובה" : "טקסט חופשי"}
                      </span>
                      {q.is_final && (
                        <span className="text-[10px] px-2 py-0.5 rounded bg-primary/20 text-primary border border-primary/30">
                          שאלת סיווג
                        </span>
                      )}
                    </div>
                    {q.subtitle && (
                      <p className="text-xs text-muted-foreground mt-1">{q.subtitle}</p>
                    )}
                    {Array.isArray(q.options) && q.options.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {q.options.map((opt, i) => (
                          <span
                            key={i}
                            className="text-[11px] px-2 py-1 rounded-md bg-background border border-border text-muted-foreground"
                          >
                            {opt.label}
                            {opt.classification && (
                              <span className="mr-1 text-primary font-semibold">
                                ({opt.classification})
                              </span>
                            )}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ol>
        )}
      </div>

      {/* Final form preview */}
      <div className="rounded-xl border border-border bg-card p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center">
            <UserSquare2 className="w-4.5 h-4.5 text-primary" />
          </div>
          <div>
            <h3 className="font-bold text-foreground">המסך האחרון — טופס השארת פרטים</h3>
            <p className="text-xs text-muted-foreground">השדות שהמשתמש ממלא בסוף השאלון</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {[
            { label: "שם מלא", key: "name", required: true, sent: true },
            { label: "שם חברה / סוכנות", key: "company", required: false, sent: false },
            { label: "אימייל", key: "email", required: true, sent: true },
            { label: "טלפון", key: "phone", required: false, sent: true },
          ].map((f) => (
            <div key={f.key} className="rounded-lg border border-border/60 bg-secondary/30 p-3">
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-semibold text-foreground">{f.label}</span>
                <div className="flex items-center gap-1">
                  {f.required && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-500/15 text-red-400 border border-red-500/30">
                      חובה
                    </span>
                  )}
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded border ${
                      f.sent
                        ? "bg-emerald-500/15 text-emerald-400 border-emerald-500/30"
                        : "bg-muted text-muted-foreground border-border"
                    }`}
                  >
                    {f.sent ? "נשלח ל-Make" : "לא נשלח"}
                  </span>
                </div>
              </div>
              <p className="text-[11px] text-muted-foreground mt-1 font-mono">{f.key}</p>
            </div>
          ))}
        </div>

        <p className="text-xs text-muted-foreground mt-4">
          * שדה "שם חברה / סוכנות" מוצג בטופס אך אינו נשמר כרגע על ישות הליד ולא נשלח ל-Webhook.
        </p>
      </div>
    </div>
  );
}