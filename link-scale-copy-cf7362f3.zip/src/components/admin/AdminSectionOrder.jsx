import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { base44 } from "@/api/base44Client";
import { GripVertical, Plus, Trash2, Eye, EyeOff, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";

// Built-in sections (cannot be deleted, only reordered/toggled)
const BUILTIN_LABELS = {
  stats: "📈 פס מספרים (Stats)",
  cta1: "🚀 קריאה לפעולה 1",
  pain: "😣 הזדהות עם הבעיה",
  objection: "🛡 אתה לא אמור לבנות קישורים בעצמך",
  roi: "📊 מחשבון עלות מול תועלת",
  testimonials: "💬 המלצות לקוחות",
  benefits: "✅ יתרונות / למה אנחנו",
  how: "⚙️ איך זה עובד (3 צעדים)",
  fit: "🎯 מתאים / לא מתאים",
  cta: "🎯 קריאה לפעולה סופית",
};

const DEFAULT_ORDER = ["stats", "cta1", "pain", "objection", "roi", "testimonials", "benefits", "how", "fit", "cta"];

export default function AdminSectionOrder() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [newTitle, setNewTitle] = useState("");

  const { data: visItems = [], isLoading: l1 } = useQuery({
    queryKey: ["section_visibility"],
    queryFn: () => base44.entities.SectionVisibility.list("", 200),
  });
  const { data: customSections = [], isLoading: l2 } = useQuery({
    queryKey: ["custom_sections"],
    queryFn: () => base44.entities.CustomSection.list("order_index", 100),
  });

  const upsertVis = useMutation({
    mutationFn: async ({ key, order_index, is_visible }) => {
      const existingAll = visItems.filter((i) => i.section_key === key);
      const payload = { section_key: key };
      if (order_index !== undefined) payload.order_index = order_index;
      if (is_visible !== undefined) payload.is_visible = is_visible;
      if (existingAll.length === 0) {
        return base44.entities.SectionVisibility.create({ is_visible: true, ...payload });
      }
      // Update the first; delete any duplicate rows to keep data clean.
      const [first, ...dupes] = existingAll;
      await Promise.all(dupes.map((d) => base44.entities.SectionVisibility.delete(d.id)));
      return base44.entities.SectionVisibility.update(first.id, payload);
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["section_visibility"] }),
  });

  const createCustom = useMutation({
    mutationFn: async (title) => {
      const maxOrder = [...visItems.map((i) => i.order_index ?? 0), DEFAULT_ORDER.length * 10].reduce((a, b) => Math.max(a, b), 0);
      const created = await base44.entities.CustomSection.create({
        title,
        section_type: "customer_story",
        badge: "סיפור לקוח",
        heading: "תנו לנו לספר לכם על",
        heading_highlight: "לקוח שלנו",
        body: "כאן מספרים את הסיפור — איך הלקוח התמודד עם הבעיה ואיך אנחנו עזרנו לו.",
        customer_name: "שם הלקוח",
        customer_role: "תפקיד / חברה",
        is_active: true,
        order_index: maxOrder + 10,
      });
      // also persist visibility entry so order is stable
      await base44.entities.SectionVisibility.create({
        section_key: `custom:${created.id}`,
        is_visible: true,
        order_index: maxOrder + 10,
      });
      return created;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["custom_sections"] });
      queryClient.invalidateQueries({ queryKey: ["section_visibility"] });
      setNewTitle("");
      toast({ title: "סקשן נוסף!", duration: 2000 });
    },
  });

  const deleteCustom = useMutation({
    mutationFn: async (id) => {
      await base44.entities.CustomSection.delete(id);
      const vis = visItems.find((i) => i.section_key === `custom:${id}`);
      if (vis) await base44.entities.SectionVisibility.delete(vis.id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["custom_sections"] });
      queryClient.invalidateQueries({ queryKey: ["section_visibility"] });
      toast({ title: "סקשן נמחק", duration: 2000 });
    },
  });

  // Build full ordered list — must match the fallback logic in useSectionOrder.js
  const ordered = React.useMemo(() => {
    const builtinKeys = Object.keys(BUILTIN_LABELS);
    const customKeys = customSections.map((cs) => `custom:${cs.id}`);
    const all = [...builtinKeys, ...customKeys];
    const fallback = (k) => {
      const i = DEFAULT_ORDER.indexOf(k);
      if (i !== -1) return (i + 1) * 10;
      return (DEFAULT_ORDER.length + 1) * 10 + all.indexOf(k);
    };
    return [...all].sort((a, b) => {
      const ra = visItems.find((i) => i.section_key === a);
      const rb = visItems.find((i) => i.section_key === b);
      const oa = ra?.order_index ?? fallback(a);
      const ob = rb?.order_index ?? fallback(b);
      return oa - ob;
    });
  }, [visItems, customSections]);

  const handleDragEnd = async (result) => {
    if (!result.destination || result.source.index === result.destination.index) return;
    const newList = Array.from(ordered);
    const [moved] = newList.splice(result.source.index, 1);
    newList.splice(result.destination.index, 0, moved);
    // Persist order for ALL sections with stable spacing (10, 20, 30…) so future inserts have room.
    await Promise.all(newList.map((key, idx) => upsertVis.mutateAsync({ key, order_index: (idx + 1) * 10 })));
    toast({ title: "סדר הסקשנים נשמר", duration: 1500 });
  };

  const toggleVisibility = async (key) => {
    const rec = visItems.find((i) => i.section_key === key);
    const current = rec ? rec.is_visible !== false : true;
    await upsertVis.mutateAsync({ key, is_visible: !current });
  };

  const getLabel = (key) => {
    if (BUILTIN_LABELS[key]) return BUILTIN_LABELS[key];
    if (key.startsWith("custom:")) {
      const id = key.slice(7);
      const cs = customSections.find((c) => c.id === id);
      return `✨ ${cs?.title || "סקשן מותאם אישית"}`;
    }
    return key;
  };

  const isVisible = (key) => {
    const rec = visItems.find((i) => i.section_key === key);
    return rec ? rec.is_visible !== false : true;
  };

  if (l1 || l2) {
    return <div className="flex justify-center py-10"><div className="w-6 h-6 border-4 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;
  }

  return (
    <div className="space-y-6" dir="rtl">
      <div>
        <h2 className="font-heading text-xl font-bold">סדר הסקשנים בעמוד</h2>
        <p className="text-sm text-muted-foreground">גרור ושחרר כדי לקבוע את סדר הסקשנים • לחץ על העין להסתיר/להציג</p>
      </div>

      {/* Add custom section */}
      <div className="rounded-2xl border border-primary/30 bg-primary/5 p-4">
        <div className="flex items-center gap-2 mb-3">
          <Sparkles className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-sm">הוסף סקשן מותאם אישית</h3>
        </div>
        <p className="text-xs text-muted-foreground mb-3">סקשן "סיפור לקוח" — כותרת, תמונה, שם הלקוח וסיפור. תוכל לערוך הכל ישירות על העמוד.</p>
        <div className="flex gap-2">
          <Input
            placeholder="שם פנימי (לדוגמה: סיפור של דני מ-X)"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            dir="rtl"
            className="flex-1"
          />
          <Button onClick={() => createCustom.mutate(newTitle)} disabled={!newTitle.trim() || createCustom.isPending}>
            <Plus className="w-4 h-4 ml-1" /> צור סקשן
          </Button>
        </div>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="sections">
          {(provided) => (
            <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-2">
              {ordered.map((key, index) => {
                const isCustom = key.startsWith("custom:");
                const visible = isVisible(key);
                return (
                  <Draggable key={key} draggableId={key} index={index}>
                    {(prov, snapshot) => (
                      <div
                        ref={prov.innerRef}
                        {...prov.draggableProps}
                        className={`flex items-center gap-3 bg-card border rounded-xl p-4 ${
                          snapshot.isDragging ? "border-primary shadow-lg" : isCustom ? "border-primary/40" : "border-border/60"
                        } ${!visible ? "opacity-50" : ""}`}
                      >
                        <div {...prov.dragHandleProps} className="cursor-grab active:cursor-grabbing text-muted-foreground hover:text-primary">
                          <GripVertical className="w-5 h-5" />
                        </div>
                        <span className="text-xs font-mono text-muted-foreground w-6 text-center">{index + 1}</span>
                        <span className="font-semibold flex-1">{getLabel(key)}</span>
                        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => toggleVisibility(key)} title={visible ? "הסתר" : "הצג"}>
                          {visible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4 text-muted-foreground" />}
                        </Button>
                        {isCustom && (
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 text-destructive"
                            onClick={() => { if (confirm("למחוק את הסקשן הזה?")) deleteCustom.mutate(key.slice(7)); }}
                            title="מחק סקשן"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    )}
                  </Draggable>
                );
              })}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      <p className="text-xs text-muted-foreground">
        💡 ה-Hero (כולל "הזדהות עם הבעיה") תמיד ראשון בעמוד, והפוטר תמיד אחרון.
        סקשנים מותאמים אישית מסוג "סיפור לקוח" שמופיעים ברצף יוצגו בעמוד מקובצים יחד תחת כותרת משותפת.
        לעריכת תוכן של סקשן — היכנס ל"עריכה על העמוד".
      </p>
    </div>
  );
}