import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Loader2, ArrowLeft, ImagePlus, X } from "lucide-react";

export default function QuestionEditor({ question, questions, onClose, onSaved }) {
  const queryClient = useQueryClient();
  const [form, setForm] = useState({
    title: question?.title || "",
    subtitle: question?.subtitle || "",
    type: question?.type || "buttons",
    is_active: question?.is_active ?? true,
    is_final: question?.is_final ?? false,
    order_index: question?.order_index ?? (questions?.length || 0),
    options: question?.options?.length
      ? question.options
      : [
          { label: "", value: "", icon: "", leads_to: "", classification: "" },
          { label: "", value: "", icon: "", leads_to: "", classification: "" },
        ],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Question.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-questions"] });
      if (onSaved) onSaved();
      else if (onClose) onClose();
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Question.update(question.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["admin-questions"] });
      if (onSaved) onSaved();
      else if (onClose) onClose();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = { ...form };
    if (data.type === "text") data.options = [];
    if (question) updateMutation.mutate(data);
    else createMutation.mutate(data);
  };

  const addOption = () => {
    setForm({
      ...form,
      options: [...form.options, { label: "", value: "", icon: "", image_url: "", leads_to: "", classification: "" }],
    });
  };

  const handleImageUpload = async (i, file) => {
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    updateOption(i, "image_url", file_url);
  };

  const removeOption = (i) => {
    setForm({ ...form, options: form.options.filter((_, idx) => idx !== i) });
  };

  const updateOption = (i, field, value) => {
    const opts = [...form.options];
    opts[i] = { ...opts[i], [field]: value };
    setForm({ ...form, options: opts });
  };

  // other questions for the "leads_to" select (excluding current)
  const otherQuestions = questions?.filter((q) => q.id !== question?.id) || [];

  const saving = createMutation.isPending || updateMutation.isPending;

  return (
    <form onSubmit={handleSubmit} className="space-y-6" dir="rtl">

      {/* ── Basic fields ── */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="md:col-span-2 space-y-1.5">
          <Label className="text-sm font-medium">כותרת השאלה <span className="text-destructive">*</span></Label>
          <Input
            required
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder='לדוגמה: "מה רמת הניסיון שלך בSEO?"'
            className="bg-secondary border-border text-base"
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-sm font-medium">תת-כותרת / הסבר <span className="text-muted-foreground font-normal">(אופציונלי)</span></Label>
          <Input
            value={form.subtitle}
            onChange={(e) => setForm({ ...form, subtitle: e.target.value })}
            placeholder="הסבר קצר שמופיע מתחת לשאלה..."
            className="bg-secondary border-border"
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-sm font-medium">סוג שאלה</Label>
          <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}>
            <SelectTrigger className="bg-secondary border-border">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="buttons">
                <div>
                  <div className="font-medium">כפתורים – בחירה יחידה</div>
                  <div className="text-xs text-muted-foreground">לחיצה על תשובה מעבירה אוטומטית</div>
                </div>
              </SelectItem>
              <SelectItem value="multiple">
                <div>
                  <div className="font-medium">בחירה מרובה</div>
                  <div className="text-xs text-muted-foreground">ניתן לסמן כמה תשובות + כפתור "המשך"</div>
                </div>
              </SelectItem>
              <SelectItem value="text">
                <div>
                  <div className="font-medium">שדה טקסט חופשי</div>
                  <div className="text-xs text-muted-foreground">המשתמש מקליד תשובה</div>
                </div>
              </SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* ── Toggles ── */}
      <div className="flex items-center gap-6 p-3 rounded-lg bg-secondary/40 border border-border/40">
        <div className="flex items-center gap-2.5">
          <Switch
            checked={form.is_active}
            onCheckedChange={(v) => setForm({ ...form, is_active: v })}
          />
          <div>
            <Label className="text-sm font-medium cursor-pointer">פעיל</Label>
            <p className="text-xs text-muted-foreground">שאלה מושבתת לא מופיעה בשאלון</p>
          </div>
        </div>
        <div className="w-px h-10 bg-border" />
        <div className="flex items-center gap-2.5">
          <Switch
            checked={form.is_final}
            onCheckedChange={(v) => setForm({ ...form, is_final: v })}
          />
          <div>
            <Label className="text-sm font-medium cursor-pointer">שאלת סיווג אחרונה 🎯</Label>
            <p className="text-xs text-muted-foreground">אחרי שאלה זו מופיע מסך התוצאה</p>
          </div>
        </div>
      </div>

      {/* ── Options ── */}
      {form.type !== "text" && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-sm font-medium">תשובות אפשריות</Label>
              <p className="text-xs text-muted-foreground mt-0.5">הגדר לאיפה כל תשובה מובילה</p>
            </div>
            <Button type="button" variant="outline" size="sm" onClick={addOption} className="border-primary/30 text-primary hover:bg-primary/10">
              <Plus className="w-3.5 h-3.5 ml-1.5" />
              הוסף תשובה
            </Button>
          </div>

          <div className="space-y-2">
            {form.options.map((opt, i) => (
              <div
                key={i}
                className="rounded-xl border border-border/50 bg-secondary/30 overflow-hidden"
              >
                {/* Option header */}
                <div className="flex items-center gap-2 px-3 pt-3 pb-2">
                  <span className="text-xs font-bold text-muted-foreground w-5 text-center">{i + 1}</span>
                  <Input
                    placeholder="טקסט התשובה (לדוגמה: כן, יש לי ניסיון)"
                    value={opt.label}
                    onChange={(e) => updateOption(i, "label", e.target.value)}
                    className="bg-card border-border flex-1 text-sm"
                  />
                  <Input
                    placeholder="🎯"
                    value={opt.icon}
                    onChange={(e) => updateOption(i, "icon", e.target.value)}
                    className="bg-card border-border w-16 text-center text-sm"
                    title="אימוג'י (אופציונלי)"
                  />
                  {/* Image upload */}
                  <div className="relative flex-shrink-0">
                    {opt.image_url ? (
                      <div className="relative">
                        <img src={opt.image_url} alt="" className="w-10 h-10 rounded-lg object-cover border border-border" />
                        <button
                          type="button"
                          onClick={() => updateOption(i, "image_url", "")}
                          className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-destructive flex items-center justify-center"
                        >
                          <X className="w-2.5 h-2.5 text-white" />
                        </button>
                      </div>
                    ) : (
                      <label className="cursor-pointer w-10 h-10 rounded-lg border border-dashed border-border/60 bg-card hover:border-primary/50 hover:bg-primary/5 flex items-center justify-center transition-colors" title="הוסף תמונה">
                        <ImagePlus className="w-4 h-4 text-muted-foreground" />
                        <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && handleImageUpload(i, e.target.files[0])} />
                      </label>
                    )}
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeOption(i)}
                    className="h-8 w-8 text-muted-foreground hover:text-destructive flex-shrink-0"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>

                {/* Option logic row */}
                <div className="flex items-center gap-2 px-3 pb-3 bg-background/30">
                  <span className="text-xs text-muted-foreground whitespace-nowrap">אם בחרו:</span>
                  <ArrowLeft className="w-3 h-3 text-muted-foreground flex-shrink-0" />

                  {/* leads_to */}
                  <Select
                    value={opt.leads_to || "__next__"}
                    onValueChange={(v) => updateOption(i, "leads_to", v === "__next__" ? "" : v)}
                  >
                    <SelectTrigger className="bg-card border-border text-xs h-8 flex-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__next__">
                        <span className="text-muted-foreground">← עבור לשאלה הבאה (ברירת מחדל)</span>
                      </SelectItem>
                      <SelectItem value="__result__">
                        <span className="text-accent font-medium">🏁 עבור ישר לתוצאה</span>
                      </SelectItem>
                      {otherQuestions.map((q) => (
                        <SelectItem key={q.id} value={q.id}>
                          <span className="text-primary">↳ {q.title}</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {/* classification */}
                  <Select
                    value={opt.classification || "__none__"}
                    onValueChange={(v) => updateOption(i, "classification", v === "__none__" ? "" : v)}
                  >
                    <SelectTrigger className="bg-card border-border text-xs h-8 w-36">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">ללא סיווג</SelectItem>
                      <SelectItem value="diy">
                        <span className="text-accent font-medium">🛠 DIY</span>
                      </SelectItem>
                      <SelectItem value="managed">
                        <span className="text-primary font-medium">🤝 Managed</span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Routing preview ── */}
      {form.type !== "text" && form.options.some(o => o.leads_to || o.classification) && (
        <div className="p-3 rounded-lg bg-primary/5 border border-primary/15 space-y-1.5">
          <p className="text-xs font-medium text-primary">תצוגת מעבר מותנה:</p>
          {form.options.filter(o => o.label).map((opt, i) => (
            <div key={i} className="flex items-center gap-2 text-xs text-muted-foreground">
              <span className="font-medium text-foreground/80">"{opt.label}"</span>
              <ArrowLeft className="w-3 h-3" />
              <span className={
                opt.leads_to === "__result__" ? "text-accent font-medium" :
                opt.leads_to ? "text-primary font-medium" :
                "text-muted-foreground"
              }>
                {opt.leads_to === "__result__"
                  ? "🏁 מסך תוצאה"
                  : opt.leads_to
                  ? `↳ ${otherQuestions.find(q => q.id === opt.leads_to)?.title || "שאלה ספציפית"}`
                  : "שאלה הבאה"}
              </span>
              {opt.classification && (
                <span className={`font-bold ${opt.classification === "diy" ? "text-accent" : "text-primary"}`}>
                  [{opt.classification.toUpperCase()}]
                </span>
              )}
            </div>
          ))}
        </div>
      )}

      {/* ── Submit ── */}
      <div className="flex justify-end gap-3 pt-2 border-t border-border/40">
        <Button type="button" variant="ghost" onClick={onClose} className="text-muted-foreground">
          ביטול
        </Button>
        <Button
          type="submit"
          disabled={saving}
          className="bg-primary hover:bg-primary/90 text-primary-foreground font-semibold px-6"
        >
          {saving ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : question ? (
            "שמור שינויים"
          ) : (
            "צור שאלה"
          )}
        </Button>
      </div>
    </form>
  );
}