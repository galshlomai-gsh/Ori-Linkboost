import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Pencil, Save, X, GripVertical, Clock, TrendingUp, Zap, Cog } from "lucide-react";

const COLOR_OPTIONS = [
  { value: "blue", label: "כחול" },
  { value: "emerald", label: "ירוק" },
  { value: "yellow", label: "צהוב" },
  { value: "purple", label: "סגול" },
  { value: "primary", label: "טורקיז" },
];

const ICON_OPTIONS = [
  { value: "Clock", label: "שעון", icon: Clock },
  { value: "TrendingUp", label: "צמיחה", icon: TrendingUp },
  { value: "Zap", label: "ברק", icon: Zap },
  { value: "Cog", label: "הגדרות", icon: Cog },
];

const emptyForm = {
  title: "",
  text: "",
  badge: "",
  author: "",
  role: "",
  color_scheme: "primary",
  icon_name: "Zap",
  avatar_url: "",
  order_index: 0,
  is_active: true,
};

function TestimonialForm({ initial, onSubmit, onCancel, submitting }) {
  const [form, setForm] = useState(initial || emptyForm);
  const update = (key, value) => setForm({ ...form, [key]: value });

  return (
    <div className="bg-card border border-border/60 rounded-xl p-5 space-y-4">
      <div className="grid md:grid-cols-2 gap-3">
        <div>
          <Label className="text-xs mb-1 block">שם הממליץ *</Label>
          <Input value={form.author} onChange={(e) => update("author", e.target.value)} placeholder="תומר לוי" />
        </div>
        <div>
          <Label className="text-xs mb-1 block">שם החברה</Label>
          <Input value={form.role} onChange={(e) => update("role", e.target.value)} placeholder="LinkBoost בע״מ" />
        </div>
      </div>

      <div>
        <Label className="text-xs mb-1 block">כותרת ההמלצה *</Label>
        <Input value={form.title} onChange={(e) => update("title", e.target.value)} placeholder="סוף סוף יציבות בקישורים" />
      </div>

      <div>
        <Label className="text-xs mb-1 block">תוכן ההמלצה *</Label>
        <Textarea
          value={form.text}
          onChange={(e) => update("text", e.target.value)}
          rows={4}
          placeholder="לפני זה כל חודש היה נראה אחרת..."
        />
      </div>

      <div>
        <Label className="text-xs mb-1 block">תגית הישג</Label>
        <Input value={form.badge} onChange={(e) => update("badge", e.target.value)} placeholder="יציבות מלאה בתהליך" />
      </div>

      <div className="grid md:grid-cols-3 gap-3">
        <div>
          <Label className="text-xs mb-1 block">צבע</Label>
          <Select value={form.color_scheme} onValueChange={(v) => update("color_scheme", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {COLOR_OPTIONS.map((c) => (
                <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs mb-1 block">אייקון</Label>
          <Select value={form.icon_name} onValueChange={(v) => update("icon_name", v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {ICON_OPTIONS.map((i) => (
                <SelectItem key={i.value} value={i.value}>{i.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs mb-1 block">סדר תצוגה</Label>
          <Input
            type="number"
            value={form.order_index}
            onChange={(e) => update("order_index", Number(e.target.value))}
          />
        </div>
      </div>

      <div>
        <Label className="text-xs mb-1 block">תמונת פרופיל (URL, אופציונלי)</Label>
        <Input
          value={form.avatar_url}
          onChange={(e) => update("avatar_url", e.target.value)}
          placeholder="ריק = avatar אוטומטי"
        />
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Switch checked={form.is_active} onCheckedChange={(v) => update("is_active", v)} />
          <Label className="text-xs">פעיל (מוצג באתר)</Label>
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-2">
        <Button variant="outline" onClick={onCancel} disabled={submitting}>
          <X className="w-4 h-4 ml-1" /> ביטול
        </Button>
        <Button onClick={() => onSubmit(form)} disabled={submitting || !form.author || !form.title || !form.text}>
          <Save className="w-4 h-4 ml-1" /> שמור
        </Button>
      </div>
    </div>
  );
}

export default function AdminTestimonials() {
  const queryClient = useQueryClient();
  const [editingId, setEditingId] = useState(null);
  const [adding, setAdding] = useState(false);

  const { data: testimonials = [], isLoading } = useQuery({
    queryKey: ["admin-testimonials"],
    queryFn: () => base44.entities.Testimonial.list("order_index"),
  });

  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["admin-testimonials"] });

  const createMut = useMutation({
    mutationFn: (data) => base44.entities.Testimonial.create(data),
    onSuccess: () => { invalidate(); setAdding(false); },
  });

  const updateMut = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Testimonial.update(id, data),
    onSuccess: () => { invalidate(); setEditingId(null); },
  });

  const deleteMut = useMutation({
    mutationFn: (id) => base44.entities.Testimonial.delete(id),
    onSuccess: invalidate,
  });

  const reorderMut = useMutation({
    mutationFn: async (newList) => {
      await Promise.all(
        newList.map((t, idx) =>
          (t.order_index ?? -1) === idx
            ? null
            : base44.entities.Testimonial.update(t.id, { order_index: idx })
        ).filter(Boolean)
      );
    },
    onSuccess: invalidate,
  });

  const handleDragEnd = (result) => {
    if (!result.destination || result.source.index === result.destination.index) return;
    const newList = Array.from(testimonials);
    const [moved] = newList.splice(result.source.index, 1);
    newList.splice(result.destination.index, 0, moved);
    // Optimistic update so UI reflects new order immediately
    queryClient.setQueryData(["admin-testimonials"], newList.map((t, idx) => ({ ...t, order_index: idx })));
    reorderMut.mutate(newList);
  };

  return (
    <div className="space-y-4" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading text-xl font-bold">ניהול המלצות</h2>
          <p className="text-sm text-muted-foreground">ערוך, הוסף ומחק את ההמלצות שמופיעות באתר</p>
        </div>
        {!adding && !editingId && (
          <Button onClick={() => setAdding(true)}>
            <Plus className="w-4 h-4 ml-1" /> הוסף המלצה
          </Button>
        )}
      </div>

      {adding && (
        <TestimonialForm
          onSubmit={(data) => createMut.mutate(data)}
          onCancel={() => setAdding(false)}
          submitting={createMut.isPending}
        />
      )}

      {isLoading ? (
        <div className="flex justify-center py-10">
          <div className="w-6 h-6 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="testimonials">
            {(provided) => (
              <div ref={provided.innerRef} {...provided.droppableProps} className="space-y-3">
                {testimonials.length === 0 && !adding && (
                  <div className="text-center py-10 text-muted-foreground text-sm border border-dashed border-border rounded-xl">
                    אין המלצות עדיין. לחץ "הוסף המלצה" כדי להתחיל.
                  </div>
                )}

                {testimonials.map((t, index) => (
                  <Draggable key={t.id} draggableId={t.id} index={index} isDragDisabled={editingId === t.id}>
                    {(prov, snapshot) => (
                      <div ref={prov.innerRef} {...prov.draggableProps}>
                        {editingId === t.id ? (
                          <TestimonialForm
                            initial={t}
                            onSubmit={(data) => updateMut.mutate({ id: t.id, data })}
                            onCancel={() => setEditingId(null)}
                            submitting={updateMut.isPending}
                          />
                        ) : (
                          <div className={`bg-card border rounded-xl p-4 flex items-start gap-4 ${snapshot.isDragging ? "border-primary shadow-lg" : "border-border/60"}`}>
                            <div {...prov.dragHandleProps} className="cursor-grab active:cursor-grabbing text-muted-foreground hover:text-primary mt-1 flex-shrink-0" title="גרור לשינוי סדר">
                              <GripVertical className="w-4 h-4" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1 flex-wrap">
                                <span className="font-semibold text-foreground">{t.author}</span>
                                {t.role && <span className="text-xs text-muted-foreground">· {t.role}</span>}
                                {!t.is_active && (
                                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-destructive/15 text-destructive border border-destructive/30">
                                    מוסתר
                                  </span>
                                )}
                                <span className="text-[10px] px-2 py-0.5 rounded-full bg-secondary text-muted-foreground">
                                  סדר: {t.order_index ?? 0}
                                </span>
                              </div>
                              <div className="text-sm font-medium text-foreground mb-1 truncate">{t.title}</div>
                              <div className="text-xs text-muted-foreground line-clamp-2">{t.text}</div>
                              {t.badge && (
                                <div className="inline-block mt-2 text-[10px] px-2 py-1 rounded-md bg-primary/10 text-primary border border-primary/20">
                                  {t.badge}
                                </div>
                              )}
                            </div>
                            <div className="flex items-center gap-1 flex-shrink-0">
                              <Button variant="ghost" size="icon" onClick={() => setEditingId(t.id)}>
                                <Pencil className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => {
                                  if (confirm(`למחוק את ההמלצה של ${t.author}?`)) deleteMut.mutate(t.id);
                                }}
                              >
                                <Trash2 className="w-4 h-4 text-destructive" />
                              </Button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>
      )}
    </div>
  );
}