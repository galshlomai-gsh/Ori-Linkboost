import React from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Eye, EyeOff, Plus } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { InlineEditProvider } from "@/components/inline-edit/InlineEditContext";
import Landing from "./Landing";

export default function AdminInline() {
  const [enabled, setEnabled] = React.useState(true);
  const [adding, setAdding] = React.useState(false);
  const queryClient = useQueryClient();

  const addCustomerStory = async () => {
    setAdding(true);
    try {
      const existing = await base44.entities.CustomSection.list("order_index", 100);
      const maxOrder = existing.reduce((m, s) => Math.max(m, s.order_index ?? 0), -1);
      await base44.entities.CustomSection.create({
        title: `סיפור לקוח ${existing.length + 1}`,
        section_type: "customer_story",
        heading: "תנו לנו לספר לכם על",
        heading_highlight: "לקוח שלנו",
        subheading: "תת-כותרת...",
        body: "ספר כאן את סיפור הלקוח...",
        order_index: maxOrder + 1,
        is_active: true,
      });
      await queryClient.invalidateQueries({ queryKey: ["custom_sections"] });
      await queryClient.invalidateQueries({ queryKey: ["section_order"] });
    } finally {
      setAdding(false);
    }
  };

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Floating toolbar */}
      <div className="fixed top-4 right-4 z-[60] flex items-center gap-2 px-3 py-2 rounded-xl bg-card/95 backdrop-blur border border-primary/30 shadow-lg shadow-primary/10">
        <Link
          to="/admin"
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-secondary hover:bg-secondary/80 text-foreground text-xs font-medium transition-colors"
        >
          <ArrowRight className="w-3.5 h-3.5" />
          חזרה לניהול
        </Link>
        <div className="h-5 w-px bg-border" />
        <button
          onClick={() => setEnabled(!enabled)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
            enabled
              ? "bg-primary text-primary-foreground hover:bg-primary/90"
              : "bg-secondary text-foreground hover:bg-secondary/80"
          }`}
        >
          {enabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
          {enabled ? "מצב עריכה פעיל" : "תצוגה רגילה"}
        </button>
        {enabled && (
          <>
            <div className="h-5 w-px bg-border" />
            <button
              onClick={addCustomerStory}
              disabled={adding}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/10 hover:bg-primary/20 text-primary text-xs font-medium transition-colors border border-primary/30 disabled:opacity-50"
            >
              <Plus className="w-3.5 h-3.5" />
              {adding ? "מוסיף..." : "סיפור לקוח חדש"}
            </button>
          </>
        )}
      </div>

      {enabled && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[60] px-4 py-2 rounded-full bg-primary/15 border border-primary/30 backdrop-blur text-xs text-primary font-medium shadow-lg">
          💡 לחץ על כל טקסט בעמוד כדי לערוך אותו · Enter לשמירה · Esc לביטול
        </div>
      )}

      <InlineEditProvider enabled={enabled}>
        <Landing />
      </InlineEditProvider>
    </div>
  );
}