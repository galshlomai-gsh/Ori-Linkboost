import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MessageSquareText, Users, ExternalLink, Sun, Moon, LayoutTemplate, Eye, Quote, ToggleRight, ListChecks, BarChart3, ArrowUpDown, Pencil, Webhook, ListTodo } from "lucide-react";
import { AnimatePresence } from "framer-motion";
import AdminQuestions from "@/components/admin/AdminQuestions";
import AdminLeads from "@/components/admin/AdminLeads";
import AdminLandingContent from "@/components/admin/AdminLandingContent";
import AdminTestimonials from "@/components/admin/AdminTestimonials";
import AdminSectionVisibility from "@/components/admin/AdminSectionVisibility";
import AdminSectionOrder from "@/components/admin/AdminSectionOrder";
import AdminFitItems from "@/components/admin/AdminFitItems";
import AdminStats from "@/components/admin/AdminStats";
import AdminWebhookSettings from "@/components/admin/AdminWebhookSettings";
import AdminTasks from "@/components/admin/AdminTasks";
import QuizContainer from "@/components/quiz/QuizContainer";

export default function Admin() {
  const [lightMode, setLightMode] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);

  return (
    <div className={`min-h-screen bg-background ${lightMode ? "light" : "dark"}`} dir="rtl">
      <header className="border-b border-border/50 px-6 py-4 sticky top-0 z-10 backdrop-blur bg-background/95">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-primary/20 flex items-center justify-center">
              <span className="text-primary font-bold text-sm">⚙</span>
            </div>
            <h1 className="font-heading text-xl font-bold">מערכת ניהול</h1>
            <span className="text-xs px-2 py-1 rounded-full bg-primary/10 text-primary border border-primary/20">Admin</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setLightMode(!lightMode)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                lightMode
                  ? "bg-gray-100 border-gray-300 text-gray-700 hover:bg-gray-200"
                  : "bg-secondary border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              {lightMode ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
              {lightMode ? "מצב כהה" : "מצב בהיר"}
            </button>
            <button
              onClick={() => setPreviewOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-primary/30 bg-primary/10 text-primary text-xs font-medium hover:bg-primary/20 transition-colors"
            >
              <Eye className="w-3.5 h-3.5" />
              תצוגת טופס
            </button>
            <Link
              to="/admin/inline"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-primary bg-primary text-primary-foreground text-xs font-bold hover:bg-primary/90 transition-colors"
            >
              <Pencil className="w-3.5 h-3.5" />
              עריכה על העמוד עצמו
            </Link>
            <Link
              to="/"
              className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1.5 transition-colors group"
            >
              <ExternalLink className="w-3.5 h-3.5 group-hover:text-primary transition-colors" />
              צפה באתר
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <Tabs defaultValue="content">
          <TabsList className="bg-secondary/95 mb-8 p-1 sticky top-[73px] z-20 backdrop-blur shadow-md">
            <TabsTrigger value="content" className="flex items-center gap-2 data-[state=active]:bg-card data-[state=active]:text-foreground">
              <LayoutTemplate className="w-4 h-4" />
              תוכן האתר
            </TabsTrigger>
            <TabsTrigger value="questions" className="flex items-center gap-2 data-[state=active]:bg-card data-[state=active]:text-foreground">
              <MessageSquareText className="w-4 h-4" />
              עריכת שאלות
            </TabsTrigger>
            <TabsTrigger value="testimonials" className="flex items-center gap-2 data-[state=active]:bg-card data-[state=active]:text-foreground">
              <Quote className="w-4 h-4" />
              המלצות
            </TabsTrigger>
            <TabsTrigger value="fit" className="flex items-center gap-2 data-[state=active]:bg-card data-[state=active]:text-foreground">
              <ListChecks className="w-4 h-4" />
              מתאים / לא מתאים
            </TabsTrigger>
            <TabsTrigger value="stats" className="flex items-center gap-2 data-[state=active]:bg-card data-[state=active]:text-foreground">
              <BarChart3 className="w-4 h-4" />
              סטטיסטיקות Hero
            </TabsTrigger>
            <TabsTrigger value="visibility" className="flex items-center gap-2 data-[state=active]:bg-card data-[state=active]:text-foreground">
              <ToggleRight className="w-4 h-4" />
              תצוגת סקשנים
            </TabsTrigger>
            <TabsTrigger value="order" className="flex items-center gap-2 data-[state=active]:bg-card data-[state=active]:text-foreground">
              <ArrowUpDown className="w-4 h-4" />
              סדר סקשנים
            </TabsTrigger>
            <TabsTrigger value="leads" className="flex items-center gap-2 data-[state=active]:bg-card data-[state=active]:text-foreground">
              <Users className="w-4 h-4" />
              לידים
            </TabsTrigger>
            <TabsTrigger value="webhook" className="flex items-center gap-2 data-[state=active]:bg-card data-[state=active]:text-foreground">
              <Webhook className="w-4 h-4" />
              Webhook
            </TabsTrigger>
            <TabsTrigger value="tasks" className="flex items-center gap-2 data-[state=active]:bg-card data-[state=active]:text-foreground">
              <ListTodo className="w-4 h-4" />
              משימות
            </TabsTrigger>
          </TabsList>
          <TabsContent value="questions">
            <AdminQuestions />
          </TabsContent>
          <TabsContent value="content">
            <AdminLandingContent />
          </TabsContent>
          <TabsContent value="testimonials">
            <AdminTestimonials />
          </TabsContent>
          <TabsContent value="fit">
            <AdminFitItems />
          </TabsContent>
          <TabsContent value="stats">
            <AdminStats />
          </TabsContent>
          <TabsContent value="visibility">
            <AdminSectionVisibility />
          </TabsContent>
          <TabsContent value="order">
            <AdminSectionOrder />
          </TabsContent>
          <TabsContent value="leads">
            <AdminLeads />
          </TabsContent>
          <TabsContent value="webhook">
            <AdminWebhookSettings />
          </TabsContent>
          <TabsContent value="tasks">
            <AdminTasks />
          </TabsContent>
        </Tabs>
      </main>

      <AnimatePresence>
        {previewOpen && (
          <QuizContainer open={previewOpen} onClose={() => setPreviewOpen(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}