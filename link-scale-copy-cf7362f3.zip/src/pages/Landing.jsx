import React, { useState, useEffect } from "react";
import { AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";
import { Settings } from "lucide-react";
import { base44 } from "@/api/base44Client";
import HeroSection from "@/components/landing/HeroSection";
import CTA1Section from "@/components/landing/CTA1Section";
import StatsSection from "@/components/landing/StatsSection";
import PainSection from "@/components/landing/PainSection";
import ObjectionBreakerSection from "@/components/landing/ObjectionBreakerSection";
import BenefitsSection from "@/components/landing/BenefitsSection";
import TestimonialsSection from "@/components/landing/TestimonialsSection";
import StickyNav from "@/components/landing/StickyNav";
import ROICalculator from "@/components/landing/ROICalculator";
import CTASection from "@/components/landing/CTASection";
import FitSection from "@/components/landing/FitSection";
import HowItWorksSection from "@/components/landing/HowItWorksSection";
import CustomSectionRenderer from "@/components/landing/CustomSectionRenderer";
import CustomerStoriesGroup from "@/components/landing/CustomerStoriesGroup";
import QuizContainer from "@/components/quiz/QuizContainer";
import { useLandingContent } from "@/hooks/useLandingContent";
import { useSectionOrder } from "@/hooks/useSectionOrder";

function FooterText() {
  const { get } = useLandingContent("footer");
  return <p className="text-sm text-muted-foreground">{get("copyright", `© ${new Date().getFullYear()} LinkBoost · כל הזכויות שמורות`)}</p>;
}

export default function Landing() {
  const [quizOpen, setQuizOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const { sections } = useSectionOrder();

  useEffect(() => {
    base44.auth.me().then((u) => {
      if (u?.role === "admin") setIsAdmin(true);
    }).catch(() => {});
  }, []);

  const startQuiz = () => setQuizOpen(true);

  const renderSection = (s) => {
    const key = s.key;
    if (s.isCustom) {
      // customer_story sections are grouped — handled in the render loop below, skip here
      return null;
    }
    switch (key) {
      case "cta1":
        return <CTA1Section key={key} onStartQuiz={startQuiz} />;
      case "stats":
        return <StatsSection key={key} />;
      case "pain":
        return <PainSection key={key} />;
      case "objection":
        return <ObjectionBreakerSection key={key} onStartQuiz={startQuiz} />;
      case "roi":
        return <ROICalculator key={key} onStartQuiz={startQuiz} />;
      case "testimonials":
        return <TestimonialsSection key={key} onStartQuiz={startQuiz} />;
      case "benefits":
        return <BenefitsSection key={key} onStartQuiz={startQuiz} />;
      case "fit":
        return <FitSection key={key} onStartQuiz={startQuiz} />;
      case "how":
        return <HowItWorksSection key={key} />;
      case "cta":
        return <CTASection key={key} onStartQuiz={startQuiz} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <StickyNav onStartQuiz={startQuiz} />
      {isAdmin && (
        <div className="fixed bottom-4 left-4 z-50 flex flex-col gap-2">
          <Link
            to="/admin/inline"
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary border border-primary text-primary-foreground text-xs font-bold hover:bg-primary/90 transition-colors shadow-lg"
          >
            <Settings className="w-3.5 h-3.5" />
            עריכה על העמוד
          </Link>
          <Link
            to="/admin"
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary/15 border border-primary/30 text-primary text-xs font-medium hover:bg-primary/25 transition-colors"
          >
            <Settings className="w-3.5 h-3.5" />
            ניהול
          </Link>
        </div>
      )}
      <HeroSection />

      {(() => {
        const visible = sections.filter((s) => s.isVisible);
        const out = [];
        let storyGroup = [];
        const flushGroup = () => {
          if (storyGroup.length > 0) {
            out.push(
              <CustomerStoriesGroup
                key={`stories-${storyGroup[0].key}`}
                sections={storyGroup.map((g) => g.customData)}
              />
            );
            storyGroup = [];
          }
        };
        for (const s of visible) {
          const isStory = s.isCustom && s.customData?.section_type === "customer_story";
          if (isStory) {
            storyGroup.push(s);
          } else if (s.isCustom && s.customData) {
            flushGroup();
            out.push(<CustomSectionRenderer key={s.key} section={s.customData} />);
          } else {
            flushGroup();
            const rendered = renderSection(s);
            if (rendered) out.push(rendered);
          }
        }
        flushGroup();
        return out;
      })()}

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border/50 text-center" dir="rtl">
        <FooterText />
      </footer>

      <AnimatePresence>
        {quizOpen && <QuizContainer open={quizOpen} onClose={() => setQuizOpen(false)} />}
      </AnimatePresence>
    </div>
  );
}