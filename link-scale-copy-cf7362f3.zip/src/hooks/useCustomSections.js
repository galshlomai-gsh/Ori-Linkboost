import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

/**
 * Fetches all active CustomSection records, sorted by order_index.
 * Each section is identified in section ordering with the prefix "custom:<id>".
 */
export function useCustomSections() {
  const { data: sections = [], isLoading } = useQuery({
    queryKey: ["custom_sections"],
    queryFn: () => base44.entities.CustomSection.list("order_index", 100),
    staleTime: 30 * 1000,
  });

  return { sections: sections.filter((s) => s.is_active !== false), allSections: sections, isLoading };
}