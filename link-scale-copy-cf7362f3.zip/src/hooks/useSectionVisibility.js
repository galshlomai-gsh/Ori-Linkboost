import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

/**
 * Hook to check if a section is visible.
 * Default: visible (true) unless explicitly hidden in DB.
 */
export function useSectionVisibility(sectionKey) {
  const { data: items = [], isLoading } = useQuery({
    queryKey: ["section_visibility"],
    queryFn: () => base44.entities.SectionVisibility.list("", 100),
    staleTime: 30 * 1000,
  });

  const record = items.find((i) => i.section_key === sectionKey);
  // Default to visible if no record exists
  const isVisible = record ? record.is_visible !== false : true;

  return { isVisible, isLoading };
}