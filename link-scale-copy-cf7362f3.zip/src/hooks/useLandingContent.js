import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export function useLandingContent(section) {
  const { data = [] } = useQuery({
    queryKey: ["landing_content", section],
    queryFn: () => base44.entities.LandingContent.filter({ section }, "order_index", 100),
    staleTime: 30000,
  });

  // Returns a getter function: get("key", "fallback")
  const get = (key, fallback = "") => {
    const item = data.find((d) => d.key === key);
    return item ? item.value : fallback;
  };

  return { get, items: data };
}