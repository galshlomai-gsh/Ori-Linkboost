import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

const DEFAULT_ORDER = ["stats", "cta1", "pain", "objection", "roi", "testimonials", "benefits", "how", "fit", "cta"];

/**
 * Returns the ordered list of all sections (built-in + custom) for the landing page,
 * each with its visibility status. Custom sections are identified by key "custom:<id>".
 */
export function useSectionOrder() {
  const { data: items = [], isLoading: loadingVis } = useQuery({
    queryKey: ["section_visibility"],
    queryFn: () => base44.entities.SectionVisibility.list("", 200),
    staleTime: 30 * 1000,
  });

  const { data: customSections = [], isLoading: loadingCustom } = useQuery({
    queryKey: ["custom_sections"],
    queryFn: () => base44.entities.CustomSection.list("order_index", 100),
    staleTime: 30 * 1000,
  });

  const allKeys = [
    ...DEFAULT_ORDER,
    ...customSections.map((cs) => `custom:${cs.id}`),
  ];

  // Fallback to default position when a section has no saved order yet.
  // Built-ins follow DEFAULT_ORDER; custom sections fall in after all built-ins.
  const fallbackOrder = (k) => {
    const i = DEFAULT_ORDER.indexOf(k);
    if (i !== -1) return (i + 1) * 10;
    // Custom sections — push after built-ins, preserving their natural array order
    return (DEFAULT_ORDER.length + 1) * 10 + allKeys.indexOf(k);
  };

  const orderedKeys = [...allKeys].sort((a, b) => {
    const ra = items.find((i) => i.section_key === a);
    const rb = items.find((i) => i.section_key === b);
    const oa = ra?.order_index ?? fallbackOrder(a);
    const ob = rb?.order_index ?? fallbackOrder(b);
    return oa - ob;
  });

  const sections = orderedKeys.map((key) => {
    const rec = items.find((i) => i.section_key === key);
    const isCustom = key.startsWith("custom:");
    const customId = isCustom ? key.slice(7) : null;
    const customData = isCustom ? customSections.find((cs) => cs.id === customId) : null;
    // Custom sections hidden if their is_active is false
    const defaultVisible = isCustom ? customData?.is_active !== false : true;
    return {
      key,
      isVisible: rec ? rec.is_visible !== false : defaultVisible,
      isCustom,
      customData,
    };
  });

  return { sections, isLoading: loadingVis || loadingCustom };
}